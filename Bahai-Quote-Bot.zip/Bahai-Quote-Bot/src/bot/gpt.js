let fetchFn = typeof fetch !== 'undefined' ? fetch : null;
if (!fetchFn) {
  fetchFn = (...args) => import('node-fetch').then(({ default: f }) => f(...args));
}

async function gptGenerate(prompt) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    console.error('[GPT] OPENAI_API_KEY not set');
    return '(GPT key missing)';
  }

  const model = process.env.OPENAI_MODEL || 'gpt-4.1-nano';
  const maxTokens = process.env.OPENAI_MAX_TOKENS ? Number(process.env.OPENAI_MAX_TOKENS) : 200;
  const apiBaseUrl = process.env.OPENAI_API_BASE_URL || 'https://api.llm7.io/v1';
  
  // Убираем слэш в конце если есть и добавляем endpoint
  const baseUrl = apiBaseUrl.replace(/\/$/, '');
  const apiUrl = `${baseUrl}/chat/completions`;

  try {
    console.log(`[GPT] Отправляем запрос к ${apiUrl} с моделью ${model}`);
    
    const res = await fetchFn(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: maxTokens
      })
    });

    console.log(`[GPT] Получен HTTP статус: ${res.status}`);

    if (!res.ok) {
      const errText = await res.text();
      console.error(`[GPT] HTTP Error ${res.status}:`, errText);
      
      // Проверяем на различные типы ошибок
      try {
        const errorData = JSON.parse(errText);
        
        if (errorData.error) {
          const errorCode = errorData.error.code;
          const errorMessage = errorData.error.message;
          
          console.error(`[GPT] API Error - Code: ${errorCode}, Message: ${errorMessage}`);
          
          if (errorCode === 'insufficient_quota') {
          return '(insufficient_quota)';
          } else if (errorCode === 'invalid_api_key') {
            return '(GPT key missing)';
          } else if (errorCode === 'rate_limit_exceeded') {
            throw new Error('rate_limit: ' + errorMessage);
          }
        }
      } catch (parseError) {
        console.warn('[GPT] Не удалось распарсить JSON ошибки:', parseError.message);
      }
      
      // Проверяем статус коды
      if (res.status === 401) {
        return '(GPT key missing)';
      } else if (res.status === 429) {
        throw new Error('rate_limit: Превышен лимит запросов');
      } else if (res.status === 500) {
        throw new Error('server_error: Ошибка сервера OpenAI');
      }
      
      throw new Error(`HTTP ${res.status}: ${errText}`);
    }

    const data = await res.json();
    console.log('[GPT] Успешно получен ответ от API');
    
    const text = data.choices?.[0]?.message?.content?.trim();
    
    if (!text) {
      console.warn('[GPT] API вернул пустой контент');
      return '(GPT empty)';
    }
    
    console.log(`[GPT] Ответ получен, длина: ${text.length} символов`);
    return text;
    
  } catch (e) {
    console.error('[GPT] Критическая ошибка:', e.message || e);
    
    // Проверяем различные типы ошибок и возвращаем специфичные коды
    if (e.message) {
      if (e.message.includes('insufficient_quota')) {
      return '(insufficient_quota)';
      } else if (e.message.includes('rate_limit')) {
        return '(rate_limit)'; // Возвращаем код вместо пробрасывания
      } else if (e.message.includes('ENOTFOUND') || e.message.includes('ECONNREFUSED')) {
        return '(network_error)';
      } else if (e.message.includes('timeout')) {
        return '(timeout)';
      } else if (e.message.includes('Failed to parse URL')) {
        return '(invalid_url)';
      } else if (e.message.includes('fetch')) {
        return '(fetch_error)';
      }
    }
    
    return '(GPT error)';
  }
}

module.exports = { gptGenerate }; 