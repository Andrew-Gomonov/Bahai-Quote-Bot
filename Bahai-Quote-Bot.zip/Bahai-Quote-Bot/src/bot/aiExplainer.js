const { gptGenerate } = require('./gpt');
const { db } = require('../core/db');
const timeManager = require('../core/timeUtils');

// Глобальное состояние функции объяснений
let explanationsEnabled = true;
let lastQuotaCheckTime = 0;
const QUOTA_CHECK_INTERVAL = 30 * 60 * 1000; // 30 минут

// Проверка статуса функции объяснений
function isExplanationsEnabled() {
  return explanationsEnabled;
}

// Отключение функции объяснений
function disableExplanations(reason = 'Превышена квота OpenAI') {
  explanationsEnabled = false;
  console.log(`[AI Explainer] Функция объяснений отключена: ${reason}`);
  
  // Записываем в базу данных время отключения
  const now = new Date().toISOString();
  db.run(
    `INSERT OR REPLACE INTO ai_explainer_status (id, enabled, disabled_at, disable_reason) 
     VALUES (1, 0, ?, ?)`,
    [now, reason],
    (err) => {
      if (err) console.error('[AI Explainer] Ошибка записи статуса:', err);
    }
  );
}

// Включение функции объяснений
function enableExplanations() {
  explanationsEnabled = true;
  console.log('[AI Explainer] Функция объяснений включена');
  
  // Обновляем статус в базе данных
  db.run(
    `INSERT OR REPLACE INTO ai_explainer_status (id, enabled, enabled_at) 
     VALUES (1, 1, ?)`,
    [new Date().toISOString()],
    (err) => {
      if (err) console.error('[AI Explainer] Ошибка записи статуса:', err);
    }
  );
}

// Функция для генерации объяснения цитаты
async function generateQuoteExplanation(quote) {
  console.log(`[AI Explainer] Начинаем генерацию для цитаты ${quote.id}`);
  
  try {
    // Проверяем, включена ли функция
    if (!explanationsEnabled) {
      console.log(`[AI Explainer] Функция отключена для цитаты ${quote.id}`);
      throw new Error('Функция ИИ объяснений временно недоступна. Обратитесь к администратору.');
    }

    // Проверяем, есть ли уже сохраненное объяснение
    const cachedExplanation = await getCachedExplanation(quote.id);
    if (cachedExplanation) {
      console.log(`[AI Explainer] Найдено кэшированное объяснение для цитаты ${quote.id}`);
      return cachedExplanation;
    }

    // Формируем промпт для GPT
    const prompt = createExplanationPrompt(quote);
    console.log(`[AI Explainer] Отправляем запрос к OpenAI для цитаты ${quote.id}`);
    
    // Генерируем объяснение через GPT с таймаутом
    const explanation = await Promise.race([
      gptGenerate(prompt),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('timeout')), 30000) // 30 секунд таймаут
      )
    ]);
    
    console.log(`[AI Explainer] Получен ответ от OpenAI для цитаты ${quote.id}: ${explanation ? 'успех' : 'пустой ответ'}`);
    
    // Проверяем на ошибки квоты
    if (explanation && (explanation === '(insufficient_quota)' || explanation.includes('insufficient_quota'))) {
      console.error('[AI Explainer] Превышена квота OpenAI, отключаю функцию');
      disableExplanations('Превышена квота OpenAI');
      throw new Error('Превышена квота OpenAI API');
    }
    
    // Проверяем на другие ошибки GPT
    if (explanation && (explanation === '(GPT error)' || explanation === '(GPT empty)' || explanation === '(GPT key missing)')) {
      console.error(`[AI Explainer] Ошибка GPT для цитаты ${quote.id}: ${explanation}`);
      throw new Error(`Ошибка OpenAI API: ${explanation}`);
    }
    
    // Проверяем на лимиты запросов
    if (explanation && explanation.includes('rate_limit')) {
      console.error(`[AI Explainer] Превышен лимит запросов для цитаты ${quote.id}`);
      throw new Error('Превышен лимит запросов OpenAI API');
    }
    
    if (explanation && explanation.trim().length > 10) {
      // Сохраняем в кэш
      console.log(`[AI Explainer] Сохраняем объяснение для цитаты ${quote.id} в кэш`);
      await cacheExplanation(quote.id, explanation);
      return explanation;
    }
    
    console.error(`[AI Explainer] Пустое или некорректное объяснение для цитаты ${quote.id}`);
    throw new Error('Получено пустое объяснение от OpenAI');
    
  } catch (error) {
    console.error(`[AI Explainer] Ошибка генерации для цитаты ${quote.id}:`, error.message);
    
    // Проверяем тип ошибки и пробрасываем её выше для корректной обработки
    if (error.message && error.message.includes('insufficient_quota')) {
      disableExplanations('Превышена квота OpenAI');
      throw new Error('insufficient_quota: Превышена квота OpenAI API');
    }
    
    if (error.message && error.message.includes('rate_limit')) {
      throw new Error('rate_limit: Превышен лимит запросов OpenAI API');
    }
    
    if (error.message && error.message.includes('timeout')) {
      throw new Error('timeout: Таймаут запроса к OpenAI API');
    }
    
    // Для других ошибок просто пробрасываем их
    throw error;
  }
}

// Создание промпта для объяснения цитаты
function createExplanationPrompt(quote) {
  let context = '';
  if (quote.author) context += `Автор: ${quote.author}\n`;
  if (quote.theme) context += `Тема: ${quote.theme}\n`;
  if (quote.source) context += `Источник: ${quote.source}\n`;

  return `Ты - эксперт по учению Бахаи и духовной мудрости. Проанализируй следующую цитату и дай краткое (3-4 предложения) объяснение её смысла и практической ценности для современного человека.

${context ? context + '\n' : ''}Цитата: "${quote.text}"

Объясни:
1. Основной смысл и послание
2. Какую практическую ценность это может принести в повседневной жизни
3. Как это может помочь в духовном развитии или решении жизненных вопросов

Ответ должен быть вдохновляющим, понятным и практичным. Пиши на русском языке.`;
}

// Получение кэшированного объяснения
function getCachedExplanation(quoteId) {
  return new Promise((resolve, reject) => {
    db.get(
      'SELECT explanation FROM quote_explanations WHERE quote_id = ?',
      [quoteId],
      (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row ? row.explanation : null);
        }
      }
    );
  });
}

// Сохранение объяснения в кэш
function cacheExplanation(quoteId, explanation) {
  return new Promise((resolve, reject) => {
    const now = new Date().toISOString();
    db.run(
      `INSERT OR REPLACE INTO quote_explanations (quote_id, explanation, created_at, updated_at) 
       VALUES (?, ?, ?, ?)`,
      [quoteId, explanation, now, now],
      (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      }
    );
  });
}

// Получение статистики объяснений для админ панели
function getExplanationStats() {
  return new Promise((resolve, reject) => {
    db.get(
      `SELECT 
         (SELECT COUNT(*) FROM quote_explanations WHERE quote_id IN (SELECT id FROM quotes))                AS total_explanations,
         (SELECT COUNT(DISTINCT quote_id) FROM quote_explanations WHERE quote_id IN (SELECT id FROM quotes)) AS quotes_with_explanations,
         (SELECT COUNT(*) FROM quotes)                                                              AS total_quotes`,
      (err, row) => {
        if (err) {
          return reject(err);
        }

        // Защита от деления на ноль
        const totalQuotes = row.total_quotes || 0;
        const quotesWithExpl = row.quotes_with_explanations || 0;
        const coverage = totalQuotes > 0 ? Math.round((quotesWithExpl / totalQuotes) * 100) : 0;

        resolve({
          total_explanations: row.total_explanations || 0,
          quotes_with_explanations: quotesWithExpl,
          total_quotes: totalQuotes,
          coverage_percentage: coverage > 100 ? 100 : coverage // ограничиваем 100%
        });
      }
    );
  });
}

// Очистка старых объяснений (для maintenance)
function clearOldExplanations(daysOld = 30) {
  return new Promise((resolve, reject) => {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);
    const cutoffISO = cutoffDate.toISOString();
    
    db.run(
      'DELETE FROM quote_explanations WHERE updated_at < ?',
      [cutoffISO],
      function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.changes);
        }
      }
    );
  });
}

// Форматирование объяснения для отправки пользователю
function formatExplanation(quote, explanation) {
  let header = `💡 **Объяснение цитаты #${quote.id}**\n\n`;
  
  // Показываем краткую версию цитаты если она длинная
  let quoteText = quote.text;
  if (quoteText.length > 100) {
    quoteText = quoteText.substring(0, 97) + '...';
  }
  
  header += `_"${quoteText}"_\n\n`;
  header += `💡 **${explanation}**\n\n`;
  header += `✨ _Используйте эту мудрость в своей повседневной жизни!_`;
  
  return header;
}

// Инициализация: загружаем состояние из базы данных
function initializeExplanationsStatus() {
  db.get(
    'SELECT enabled, disabled_at, disable_reason FROM ai_explainer_status WHERE id = 1',
    (err, row) => {
      if (err) {
        // Если таблица не существует (например, в тестах), просто создаем её
        if (err.code === 'SQLITE_ERROR' && err.message.includes('no such table')) {
          console.log('[AI Explainer] Таблица ai_explainer_status не найдена, создаю...');
          db.run(`CREATE TABLE IF NOT EXISTS ai_explainer_status (
            id INTEGER PRIMARY KEY DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            disabled_at TEXT,
            enabled_at TEXT,
            disable_reason TEXT
          )`, (createErr) => {
            if (createErr) {
              console.error('[AI Explainer] Ошибка создания таблицы:', createErr);
            } else {
              console.log('[AI Explainer] Таблица создана, функция включена по умолчанию');
            }
          });
          return;
        }
        console.error('[AI Explainer] Ошибка загрузки статуса:', err);
        return;
      }
      
      if (row) {
        explanationsEnabled = row.enabled === 1;
        console.log(`[AI Explainer] Загружен статус: ${explanationsEnabled ? 'включено' : 'отключено'}`);
        if (!explanationsEnabled && row.disable_reason) {
          console.log(`[AI Explainer] Причина отключения: ${row.disable_reason}`);
        }
      }
    }
  );
}

// Получение статуса функции для админ панели
function getExplanationsStatus() {
  return new Promise((resolve, reject) => {
    db.get(
      'SELECT enabled, disabled_at, disable_reason, enabled_at FROM ai_explainer_status WHERE id = 1',
      (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            enabled: explanationsEnabled,
            disabled_at: row && row.disabled_at ? timeManager.formatForDisplay(row.disabled_at) : null,
            disable_reason: row ? row.disable_reason : null,
            enabled_at: row && row.enabled_at ? timeManager.formatForDisplay(row.enabled_at) : null
          });
        }
      }
    );
  });
}

// Автоматическая проверка квоты (пытается сделать тестовый запрос)
async function checkQuotaStatus() {
  if (!explanationsEnabled || Date.now() - lastQuotaCheckTime < QUOTA_CHECK_INTERVAL) {
    return explanationsEnabled;
  }
  
  lastQuotaCheckTime = Date.now();
  
  try {
    // Делаем минимальный тестовый запрос
    const testResult = await gptGenerate('Test');
    
    if (testResult && testResult.includes('insufficient_quota')) {
      disableExplanations('Превышена квота OpenAI (автопроверка)');
      return false;
    }
    
    return true;
  } catch (error) {
    if (error.message && error.message.includes('insufficient_quota')) {
      disableExplanations('Превышена квота OpenAI (автопроверка)');
      return false;
    }
    return explanationsEnabled;
  }
}

// Инициализируем при загрузке модуля
initializeExplanationsStatus();

module.exports = {
  generateQuoteExplanation,
  getCachedExplanation,
  cacheExplanation,
  getExplanationStats,
  clearOldExplanations,
  formatExplanation,
  isExplanationsEnabled,
  enableExplanations,
  disableExplanations,
  getExplanationsStatus,
  checkQuotaStatus,
  initializeExplanationsStatus
}; 