const { DateTime } = require('luxon');
const { gptGenerate } = require('../bot/gpt'); // ИЗМЕНЕНО
const { DEFAULT_TZ } = require('./db'); // ИЗМЕНЕНО (пока так, потом db.js тоже переедет)
const { recordQuoteRead, updateDailyStreak } = require('../bot/stats');

async function startScheduler(db, bot, getRandomQuote, broadcastToAll) {
  async function handleBroadcast(b) {
    let text = sanitizeText(b.message);
    if (b.use_gpt) {
      try {
        text = sanitizeText(await gptGenerate(b.gpt_prompt || 'Сгенерируй вдохновляющий пост для Telegram на основе цитат Баха\'и (до 400 символов)'));
      } catch (e) {
        console.error('[SCHEDULER] GPT error:', e);
      }
    }
    let targets=null;
    if(b.targets){
      const raw = String(b.targets).split(/[,\s]+/).filter(Boolean);
      targets = [];
      for(const tok of raw){
        if(/^g:\d+$/i.test(tok)){
          const gid = Number(tok.split(':')[1]);
          // Получаем участников группы
          const members = await new Promise((resolve,reject)=>{
            db.all('SELECT chat_id FROM group_members WHERE group_id = ?', [gid], (err, rows)=>{
              if(err) return reject(err);
              resolve(rows.map(r=>r.chat_id));
            });
          });
          targets.push(...members);
        }else if(/^-?\d+$/.test(tok)){
          targets.push(Number(tok));
        }
      }
      // Удаляем дубликаты
      targets = Array.from(new Set(targets));
    }
    await broadcastToAll(text, b.image, targets);
    // Обновляем сохранённое сообщение, чтобы в админ-панели отображался последний сгенерированный текст
    db.run('UPDATE broadcasts SET message = ? WHERE id = ?', [text, b.id]);
  }

  function sanitizeText(raw){
    if(!raw) return '';
    if(typeof raw==='string'){
      const t=raw.trim();
      if(t.startsWith('{')){
        try{const o=JSON.parse(t);const c=o?.choices?.[0]?.message?.content;if(c) return c.trim();}catch{}
      }
      return t;
    }
    if(typeof raw==='object'){
      try{const c=raw?.choices?.[0]?.message?.content;if(c) return c.trim();return JSON.stringify(raw);}catch{return String(raw);} }
    return String(raw);
  }

  async function scheduleLoop() {
    const nowUtc = DateTime.utc();

    // Daily quotes
    db.all('SELECT chat_id, timezone, daily_time, last_daily_sent FROM users WHERE daily_enabled = 1', (err, rows) => {
      if (err) return console.error(err);
      rows.forEach(async (u) => {
        const userNow = nowUtc.setZone(u.timezone);
        const timeNow = userNow.toFormat('HH:mm');
        if (timeNow === u.daily_time) {
          const today = userNow.toISODate();
          if (u.last_daily_sent !== today) {
            const q = getRandomQuote();
            if (!q) return;
            
            try {
              // Отправляем цитату
              await bot.sendMessage(u.chat_id, `🌅 **Цитата дня**\n\n#${q.id}\n\n${q.text}`, {
                reply_markup: {
                  inline_keyboard: [[{ text: '🔄 Ещё', callback_data: 'more' }]],
                },
                parse_mode: 'Markdown'
              });
              
              // Обновляем дату последней отправки
              db.run('UPDATE users SET last_daily_sent = ? WHERE chat_id = ?', [today, u.chat_id]);
              
              // Записываем статистику прочтения
              await recordQuoteRead(u.chat_id, q.id, 'daily');
              
              // Обновляем ежедневный стрик
              const newStreak = await updateDailyStreak(u.chat_id);
              
              // Уведомляем о важных стриках
              if (newStreak === 3) {
                bot.sendMessage(u.chat_id, '🔥 **Поздравляем!** Вы читаете цитаты 3 дня подряд!', { parse_mode: 'Markdown' });
              } else if (newStreak === 7) {
                bot.sendMessage(u.chat_id, '🔥🔥 **Невероятно!** Неделя постоянного чтения цитат!', { parse_mode: 'Markdown' });
              } else if (newStreak === 30) {
                bot.sendMessage(u.chat_id, '🔥🔥🔥 **Потрясающе!** Целый месяц мудрости! Вы - настоящий мудрец!', { parse_mode: 'Markdown' });
              } else if (newStreak > 0 && newStreak % 10 === 0) {
                bot.sendMessage(u.chat_id, `🔥 **${newStreak} дней подряд!** Продолжайте в том же духе!`, { parse_mode: 'Markdown' });
              }
              
              // После основной цитаты случайно напоминаем о поддержке
              const PROB = 0.5; // 50 %
              if (Math.random() < PROB) {
                db.all('SELECT key, value FROM support_settings', (err3, rows2) => {
                  const settings = {
                    paypal_url: 'https://paypal.me/ANDREIGOMONOV?country.x=MD&locale.x=en_US',
                    github_url: 'https://github.com/Andrew-Gomonov/Bahai-Quote-Bot'
                  };
                  if (!err3 && rows2) rows2.forEach(r=> settings[r.key]=r.value);
                  const remindText = '💝 *Поддержите развитие Bahá\'í Quote Bot!*';
                  const kb = { inline_keyboard: [[{text:'💳 PayPal', url: settings.paypal_url}], [{text:'⭐ GitHub', url: settings.github_url}]] };
                  bot.sendMessage(u.chat_id, remindText, {parse_mode:'Markdown', reply_markup: kb}).catch(()=>{});
                });
              }
              
            } catch (e) {
              console.error('[SCHEDULER] Error sending daily quote:', e);
            }
          }
        }
      });
    });

    // One-time broadcasts
    db.all("SELECT * FROM broadcasts WHERE type = 'push' AND sent = 0", (err, rows) => {
      if (err) return console.error(err);
      rows.forEach(async (b) => {
        const due = DateTime.fromISO(b.schedule, { zone: 'utc' });
        if (due <= nowUtc) {
          await handleBroadcast(b);
          db.run('UPDATE broadcasts SET sent = 1 WHERE id = ?', [b.id]);
        }
      });
    });

    // Weekly broadcasts
    db.all("SELECT * FROM broadcasts WHERE type = 'weekly'", (err, rows) => {
      if (err) return console.error(err);

      // Используем локальную временную зону админа для корректного сравнения времени
      const nowLocal = nowUtc.setZone(DEFAULT_TZ);
      const nowDay = nowLocal.weekday; // 1-7 (ISO weekday)
      const nowTime = nowLocal.toFormat('HH:mm');
      const todayLocal = nowLocal.toISODate();

      rows.forEach(async (b) => {
        const [dayStr, timeStr] = (b.schedule || '').split('|');
        const day = Number(dayStr); // 1-7

        if (day === nowDay && timeStr === nowTime) {
          if (b.last_sent_date !== todayLocal) {
            await handleBroadcast(b);
            db.run('UPDATE broadcasts SET last_sent_date = ? WHERE id = ?', [todayLocal, b.id]);
          }
        }
      });
    });

    // Daily broadcasts (admin time in DEFAULT_TZ)
    db.all("SELECT * FROM broadcasts WHERE type = 'daily'", (err, rows) => {
      if (err) return console.error(err);
      const nowLocal = nowUtc.setZone(DEFAULT_TZ);
      const nowTime = nowLocal.toFormat('HH:mm');
      const todayLocal = nowLocal.toISODate();
      rows.forEach(async (b) => {
        if (b.schedule?.trim().slice(0,5) === nowTime) {
          if (b.last_sent_date !== todayLocal) {
            await handleBroadcast(b);
            db.run('UPDATE broadcasts SET last_sent_date = ? WHERE id = ?', [todayLocal, b.id]);
          }
        }
      });
    });
  }

  // Run immediately and then every minute
  scheduleLoop();
  setInterval(scheduleLoop, 60 * 1000);
}

module.exports = { startScheduler }; 