const express = require('express');
const router = express.Router();
const {
  getExplanationsStatus,
  enableExplanations,
  disableExplanations,
  getExplanationStats,
  clearOldExplanations,
  generateQuoteExplanation,
  getCachedExplanation
} = require('../../bot/aiExplainer');

// Timeout (ms) for OpenAI API test, configurable via env
const API_TEST_TIMEOUT = parseInt(process.env.OPENAI_API_TIMEOUT || '30000');

// Страница управления ИИ объяснениями
router.get('/', async (req, res) => {
  try {
    const status = await getExplanationsStatus();
    const stats = await getExplanationStats();
    
    res.render('ai-explainer', {
      title: 'Управление ИИ объяснениями',
      status,
      stats,
      currentPage: 'ai-explainer',
      styles: ['ai-explainer.css']
    });
  } catch (error) {
    console.error('Error loading AI explainer page:', error);
    res.render('error', { 
      title: 'Ошибка',
      error: 'Не удалось загрузить данные' 
    });
  }
});

// Включение функции объяснений
router.post('/enable', (req, res) => {
  try {
    enableExplanations();
    res.redirect('/ai-explainer?success=' + encodeURIComponent('Функция ИИ объяснений включена'));
  } catch (error) {
    console.error('Error enabling explanations:', error);
    res.redirect('/ai-explainer?error=' + encodeURIComponent('Ошибка включения функции'));
  }
});

// Отключение функции объяснений
router.post('/disable', (req, res) => {
  try {
    const reason = req.body.reason || 'Отключено администратором';
    disableExplanations(reason);
    res.redirect('/ai-explainer?success=' + encodeURIComponent('Функция ИИ объяснений отключена'));
  } catch (error) {
    console.error('Error disabling explanations:', error);
    res.redirect('/ai-explainer?error=' + encodeURIComponent('Ошибка отключения функции'));
  }
});

// Очистка старых объяснений
router.post('/clear-old', async (req, res) => {
  try {
    const days = parseInt(req.body.days) || 30;
    const deleted = await clearOldExplanations(days);
    res.json({ success: true, deleted });
  } catch (error) {
    console.error('Error clearing old explanations:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// Массовая генерация объяснений
router.post('/generate-all', async (req, res) => {
  try {
    const { db } = require('../../core/db');
    
    // Получаем все цитаты без объяснений
    const quotes = await new Promise((resolve, reject) => {
      db.all(`
        SELECT q.id, q.text 
        FROM quotes q 
        LEFT JOIN quote_explanations e ON q.id = e.quote_id 
        WHERE e.quote_id IS NULL
        LIMIT 10
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
    
    let generated = 0;
    
    for (const quote of quotes) {
      try {
        await generateQuoteExplanation(quote);
        generated++;
      } catch (error) {
        console.error(`Error generating explanation for quote ${quote.id}:`, error);
        // Продолжаем генерацию для остальных цитат
      }
    }
    
    res.json({ 
      success: true, 
      generated, 
      total: quotes.length,
      message: `Сгенерировано ${generated} объяснений из ${quotes.length} цитат`
    });
    
  } catch (error) {
    console.error('Error in mass generation:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

// Тестирование OpenAI API (улучшенная версия)
router.post('/test-api', async (req, res) => {
  console.log('[API-Test] Начинаем проверку OpenAI API...');
  
  try {
    // Проверяем наличие API ключа
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      console.error('[API-Test] OPENAI_API_KEY не установлен');
      return res.json({ 
        success: false, 
        message: 'API ключ OpenAI не настроен в переменных окружения',
        details: 'Установите переменную OPENAI_API_KEY'
      });
    }
    
    const { gptGenerate } = require('../../bot/gpt');
    
    // Делаем реальный тестовый запрос с простым промптом
    console.log('[API-Test] Отправляем тестовый запрос к OpenAI...');
    let timeoutId;
    const testResult = await Promise.race([
      // Основной запрос к GPT
      (async () => {
        const result = await gptGenerate('Ответь одним словом: "OK"');
        clearTimeout(timeoutId);
        return result;
      })(),
      // Таймаут-обёртка с возможностью очистки
      new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('timeout')), API_TEST_TIMEOUT);
      })
    ]);
    
    console.log('[API-Test] Получен ответ от OpenAI:', testResult);
    
    // Проверяем различные типы ошибок
    if (!testResult) {
      console.error('[API-Test] Пустой ответ от API');
      return res.json({ 
        success: false, 
        message: 'Получен пустой ответ от OpenAI API',
        details: 'API вернул null или undefined'
      });
    }
    
    if (testResult === '(GPT key missing)') {
      console.error('[API-Test] API ключ отсутствует');
      return res.json({ 
        success: false, 
        message: 'API ключ OpenAI не найден или недействителен',
        details: 'Проверьте правильность API ключа'
      });
    }
    
    if (testResult === '(insufficient_quota)' || testResult.includes('insufficient_quota')) {
      console.error('[API-Test] Превышена квота');
      return res.json({ 
        success: false, 
        message: 'Превышена квота OpenAI API',
        details: 'Недостаточно средств на аккаунте или исчерпан лимит запросов'
      });
    }
    
    // Проверяем различные типы ошибок GPT
    if (testResult === '(network_error)') {
      console.error('[API-Test] Ошибка сети');
      return res.json({ 
        success: false, 
        message: 'Проблема с подключением к OpenAI',
        details: 'Не удалось установить соединение с серверами OpenAI. Проверьте настройки сети и URL API.'
      });
    }
    
    if (testResult === '(invalid_url)') {
      console.error('[API-Test] Неверный URL API');
      return res.json({ 
        success: false, 
        message: 'Неверно настроен URL OpenAI API',
        details: 'Проверьте переменную OPENAI_API_BASE_URL в настройках сервера'
      });
    }
    
    if (testResult === '(fetch_error)') {
      console.error('[API-Test] Ошибка fetch');
      return res.json({ 
        success: false, 
        message: 'Ошибка HTTP запроса к OpenAI',
        details: 'Проблема при выполнении запроса. Проверьте настройки прокси и сети.'
      });
    }
    
    if (testResult === '(timeout)') {
      console.error('[API-Test] Таймаут запроса');
      return res.json({ 
        success: false, 
        message: 'Таймаут запроса к OpenAI API',
        details: 'Сервер OpenAI не отвечает или отвечает слишком медленно'
      });
    }
    
    if (testResult === '(rate_limit)') {
      console.error('[API-Test] Превышен лимит запросов');
      return res.json({ 
        success: false, 
        message: 'Превышен лимит запросов OpenAI API',
        details: 'Слишком много запросов в минуту. Подождите перед повторной попыткой.'
      });
    }
    
    if (testResult === '(GPT error)') {
      console.error('[API-Test] Общая ошибка GPT');
      return res.json({ 
        success: false, 
        message: 'Неизвестная ошибка OpenAI API',
        details: 'Произошла неопознанная ошибка при обращении к API'
      });
    }
    
    if (testResult === '(GPT empty)') {
      console.error('[API-Test] Пустой ответ от GPT');
      return res.json({ 
        success: false, 
        message: 'OpenAI API вернул пустой ответ',
        details: 'API работает, но не генерирует контент'
      });
    }
    
    // Проверяем, что ответ содержит осмысленный контент
    if (testResult.length < 2) {
      console.error('[API-Test] Слишком короткий ответ:', testResult);
      return res.json({ 
        success: false, 
        message: 'OpenAI API вернул некорректный ответ',
        details: `Получен ответ: "${testResult}" (слишком короткий)`
      });
    }
    
    // Если дошли до сюда - API работает нормально
    console.log('[API-Test] API проверка успешна');
    res.json({ 
      success: true, 
      message: 'OpenAI API работает корректно',
      details: `Тестовый ответ: "${testResult.substring(0, 50)}${testResult.length > 50 ? '...' : ''}"`
    });
    
  } catch (error) {
    console.error('[API-Test] Критическая ошибка:', error);
    
    // Детальная обработка различных типов ошибок
    let errorMessage = 'Неизвестная ошибка API';
    let errorDetails = error.message;
    
    if (error.message.includes('timeout')) {
      errorMessage = 'Таймаут запроса к OpenAI API';
      errorDetails = 'API не отвечает в течение 15 секунд';
    } else if (error.message.includes('insufficient_quota')) {
      errorMessage = 'Превышена квота OpenAI API';
      errorDetails = 'Недостаточно средств на аккаунте';
    } else if (error.message.includes('rate_limit')) {
      errorMessage = 'Превышен лимит запросов OpenAI API';
      errorDetails = 'Слишком много запросов в минуту';
    } else if (error.message.includes('invalid_api_key')) {
      errorMessage = 'Недействительный API ключ OpenAI';
      errorDetails = 'Проверьте правильность API ключа';
    } else if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED')) {
      errorMessage = 'Проблема с подключением к OpenAI';
      errorDetails = 'Проверьте подключение к интернету и настройки сети';
    } else if (error.message.includes('HTTP 401')) {
      errorMessage = 'Неавторизованный доступ к OpenAI API';
      errorDetails = 'Проверьте правильность API ключа';
    } else if (error.message.includes('HTTP 429')) {
      errorMessage = 'Превышен лимит запросов OpenAI API';
      errorDetails = 'Слишком много запросов, повторите позже';
    } else if (error.message.includes('HTTP 500')) {
      errorMessage = 'Внутренняя ошибка сервера OpenAI';
      errorDetails = 'Попробуйте позже, проблема на стороне OpenAI';
    }
    
    res.json({ 
      success: false, 
      message: errorMessage,
      details: errorDetails
    });
  }
});

// API для получения количества цитат без объяснений
router.get('/api/quotes-count', async (req, res) => {
  try {
    const { db } = require('../../core/db');
    
    const count = await new Promise((resolve, reject) => {
      db.get(`
        SELECT COUNT(*) as count
        FROM quotes q 
        LEFT JOIN quote_explanations e ON q.id = e.quote_id 
        WHERE e.quote_id IS NULL
      `, (err, row) => {
        if (err) reject(err);
        else resolve(row.count);
      });
    });
    
    res.json({ count });
  } catch (error) {
    console.error('Error getting quotes count:', error);
    res.status(500).json({ error: 'Не удалось получить количество цитат' });
  }
});

// API для генерации одной цитаты (улучшенная версия)
router.post('/generate-single', async (req, res) => {
  try {
    const { db } = require('../../core/db');
    
    // Получаем первую доступную цитату без объяснения
    const quote = await new Promise((resolve, reject) => {
      db.get(`
        SELECT q.id, q.text, q.author, q.source
        FROM quotes q 
        LEFT JOIN quote_explanations e ON q.id = e.quote_id 
        WHERE e.quote_id IS NULL
        ORDER BY q.id ASC
        LIMIT 1
      `, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
    
    if (!quote) {
      return res.json({ success: false, message: 'Нет цитат для обработки' });
    }
    
    console.log(`[AI-Explainer] Начинаем генерацию для цитаты ${quote.id}: "${quote.text.substring(0, 50)}..."`);
    
    try {
      await generateQuoteExplanation(quote);
      console.log(`[AI-Explainer] Успешно сгенерировано объяснение для цитаты ${quote.id}`);
      
      res.json({ 
        success: true, 
        quoteId: quote.id,
        quoteText: quote.text,
        message: 'Объяснение сгенерировано'
      });
    } catch (genError) {
      console.error(`[AI-Explainer] Ошибка генерации для цитаты ${quote.id}:`, genError);
      
      // Проверяем тип ошибки
      let errorMessage = genError.message;
      if (errorMessage.includes('insufficient_quota')) {
        errorMessage = 'Превышена квота OpenAI API';
      } else if (errorMessage.includes('rate_limit')) {
        errorMessage = 'Превышен лимит запросов OpenAI API';
      } else if (errorMessage.includes('timeout')) {
        errorMessage = 'Таймаут запроса к OpenAI API';
      }
      
      res.json({ 
        success: false, 
        quoteId: quote.id,
        quoteText: quote.text,
        message: errorMessage,
        canContinue: !errorMessage.includes('квота') // Можно ли продолжать генерацию
      });
    }
    
  } catch (error) {
    console.error('[AI-Explainer] Критическая ошибка в generate-single:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Критическая ошибка: ' + error.message,
      canContinue: false
    });
  }
});

// API для получения статуса (JSON)
router.get('/api/status', async (req, res) => {
  try {
    const status = await getExplanationsStatus();
    const stats = await getExplanationStats();
    res.json({ status, stats });
  } catch (error) {
    console.error('Error getting API status:', error);
    res.status(500).json({ error: 'Не удалось получить статус' });
  }
});

module.exports = router; 