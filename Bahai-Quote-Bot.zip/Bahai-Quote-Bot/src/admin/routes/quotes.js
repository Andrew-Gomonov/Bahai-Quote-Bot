const express = require('express');
const router = express.Router();

const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const fs = require('fs');

const { db: sharedDb } = require('../../core/db');

// Helpers
function db() {
  return sharedDb;
}

// Список цитат + форма добавления
router.get('/', (req, res) => {
  res.render('quotes', { 
    title: 'Цитаты', 
    rows: [], // Пустой массив, данные будут загружаться через AJAX
    useDataTables: true,
    styles: ['table-image-preview.css', 'action-buttons.css']
  });
});

// AJAX endpoint для серверной пагинации
router.get('/data', (req, res) => {
  const d = db();
  
  // Параметры DataTables
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';
  
  // Строим WHERE условие для поиска
  let whereClause = '';
  let params = [];
  if (searchValue) {
    whereClause = 'WHERE q.text LIKE ?';
    params.push(`%${searchValue}%`);
  }
  
  // Получаем общее количество записей
  const countSQL = `SELECT COUNT(*) as total FROM quotes q ${whereClause}`;
  
  d.get(countSQL, params, (err, countResult) => {
    if (err) {
      console.error('Error counting quotes:', err);
      return res.status(500).json({ error: err.message });
    
    }
    
    const totalRecords = countResult.total;
    
    // Получаем данные для текущей страницы
    const quotesSQL = `
      SELECT q.id, q.text, 
             CASE WHEN e.explanation IS NOT NULL THEN 1 ELSE 0 END as has_explanation
      FROM quotes q 
      LEFT JOIN quote_explanations e ON q.id = e.quote_id 
      ${whereClause}
      ORDER BY q.id DESC
      LIMIT ? OFFSET ?
    `;
    
    const queryParams = [...params, length, start];
    
    d.all(quotesSQL, queryParams, (err, rows) => {
      if (err) {
        console.error('Error loading quotes:', err);
        return res.status(500).json({ error: err.message });
      }
      
      // Форматируем данные для DataTables
      const data = rows.map(row => ({
        id: row.id,
        text: row.text,
        has_explanation: row.has_explanation
      }));
      
      res.json({
        draw: draw,
        recordsTotal: totalRecords,
        recordsFiltered: totalRecords,
        data: data
      });
    });
  });
});





// Добавление цитаты
router.post('/', (req, res) => {
  const text = (req.body.text || '').trim();
  if (!text) return res.redirect('/quotes');
  const d = db();
  d.run('INSERT INTO quotes(text) VALUES (?)', [text], () => {
    res.redirect('/quotes');
  });
});

// Удаление цитаты
router.post('/delete/:id', (req, res) => {
  const id = Number(req.params.id);
  const d = db();
  
  // Проверяем Content-Type для определения типа ответа
  const isAjax = req.headers['content-type'] === 'application/json' || 
                 req.headers.accept && req.headers.accept.includes('application/json');
  
  d.run('DELETE FROM quotes WHERE id = ?', [id], function(err) {
    if (err) {
      console.error('Error deleting quote:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка удаления цитаты' });
      } else {
        return res.redirect('/quotes');
      }
    }
    
    if (isAjax) {
      res.json({ success: true, message: `Цитата #${id} успешно удалена` });
    } else {
      res.redirect('/quotes');
    }
  });
});

// Обновление цитаты
router.post('/update/:id', (req, res) => {
  const id = Number(req.params.id);
  const text = (req.body.text || '').trim();
  if (!text) return res.redirect('/quotes');
  const d = db();
  d.run('UPDATE quotes SET text = ? WHERE id = ?', [text, id], () => {
    res.redirect('/quotes');
  });
});

// Импорт цитат из JSON
router.post('/import', upload.single('quotesFile'), (req, res) => {
  if (!req.file) {
    return res.redirect('/quotes');
  }

  try {
    const content = fs.readFileSync(req.file.path, 'utf8');
    const quotes = JSON.parse(content);

    if (!Array.isArray(quotes)) {
      throw new Error('Invalid JSON format: expected array');
    }

    const d = db();
    const stmt = d.prepare('INSERT INTO quotes(text) VALUES (?)');

    let imported = 0;
    quotes.forEach((quote) => {
      if (quote && typeof quote.text === 'string' && quote.text.trim()) {
        stmt.run(quote.text.trim());
        imported++;
      }
    });

    stmt.finalize();

    // Удаляем загруженный файл
    fs.unlinkSync(req.file.path);

    console.log(`[ADMIN] Импортировано ${imported} цитат из JSON`);
    res.redirect('/quotes');
  } catch (err) {
    console.error('[ADMIN] Ошибка импорта:', err);
    // Cleanup on error
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    res.redirect('/quotes');
  }
});

// Обновление объяснения цитаты
router.post('/explanation/:id', (req, res) => {
  const quoteId = Number(req.params.id);
  const explanation = (req.body.explanation || '').trim();
  
  if (!explanation) {
    // Удаляем объяснение если оно пустое
    const d = db();
    d.run('DELETE FROM quote_explanations WHERE quote_id = ?', [quoteId], (err) => {
      if (err) {
        console.error('Error deleting explanation:', err);
        return res.status(500).json({ success: false, message: 'Ошибка удаления объяснения' });
      }
      res.json({ success: true, message: 'Объяснение удалено' });
    });
    return;
  }
  
  const d = db();
  const now = new Date().toISOString();
  
  // Используем INSERT OR REPLACE для создания или обновления
  d.run(`
    INSERT OR REPLACE INTO quote_explanations (quote_id, explanation, created_at, updated_at) 
    VALUES (?, ?, COALESCE((SELECT created_at FROM quote_explanations WHERE quote_id = ?), ?), ?)
  `, [quoteId, explanation, quoteId, now, now], (err) => {
    if (err) {
      console.error('Error updating explanation:', err);
      return res.status(500).json({ success: false, message: 'Ошибка сохранения объяснения' });
    }
    res.json({ success: true, message: 'Объяснение сохранено' });
  });
});

// Получение объяснения цитаты (AJAX)
router.get('/explanation/:id', (req, res) => {
  const quoteId = Number(req.params.id);
  const d = db();
  
  d.get('SELECT explanation FROM quote_explanations WHERE quote_id = ?', [quoteId], (err, row) => {
    if (err) {
      console.error('Error getting explanation:', err);
      return res.status(500).json({ success: false, message: 'Ошибка получения объяснения' });
    }
    
    res.json({ 
      success: true, 
      explanation: row ? row.explanation : '' 
    });
  });
});

module.exports = router; 