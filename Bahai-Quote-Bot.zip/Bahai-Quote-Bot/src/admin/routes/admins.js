const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const TelegramBot = require('node-telegram-bot-api');

const bcrypt = require('bcrypt');
const { db: sharedDb } = require('../../core/db');
const { isAuthenticated, createSecureSession, securityManager } = require('../../core/auth');

function db() { return sharedDb; }

// Configuration for avatar uploads
const avatarDir = path.join(__dirname, '..', '..', '..', 'uploads', 'avatars');
if (!fs.existsSync(avatarDir)) {
  fs.mkdirSync(avatarDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, avatarDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = file.fieldname + '-' + Date.now() + ext;
    cb(null, safeName);
  }
});

function fileFilter(req, file, cb) {
  const allowed = ['image/jpeg', 'image/png', 'image/gif'];
  if (allowed.includes(file.mimetype)) cb(null, true); else cb(new Error('Invalid file type'));
}

const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 }, fileFilter });

// Middleware: only super admins allowed
function requireSuper(req, res, next) {
  if (req.user && req.user.role === 'super') return next();
  return res.status(403).send('Forbidden');
}

// Telegram API helper (reuse)
let tgBot = null;
function getBot() {
  if (!tgBot) tgBot = new TelegramBot(process.env.BOT_TOKEN, { polling: false });
  return tgBot;
}

async function fetchAndCacheTgAdminInfo(chatId) {
  try {
    const bot = getBot();
    const chat = await bot.getChat(chatId);
    const firstName = chat.first_name || '';
    const username = chat.username || '';
    const d = db();
    d.run('UPDATE admins SET first_name = ?, username = ? WHERE chat_id = ?', [firstName, username, chatId]);
    return { first_name: firstName, username };
  } catch (e) {
    console.warn('[TG] Не удалось получить info для admin', chatId, e.message);
    return { first_name: '', username: '' };
  }
}

// List admins page
router.get('/', (req, res) => {
      res.render('admins', {
        title: 'Админы',
    tgAdmins: [], // Пустой массив, данные будут загружаться через AJAX
    webAdmins: [], // Пустой массив, данные будут загружаться через AJAX
        isSuper: req.user?.role === 'super',
        useDataTables: true,
        styles: ['user-profile.css', 'action-buttons.css'],
        scripts: ['avatar-preview.js']
  });
});

// AJAX endpoint для серверной пагинации Telegram админов
router.get('/tg-data', async (req, res) => {
  const d = db();
  
  // Параметры DataTables
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';
  
  // Строим WHERE условие для поиска
  let whereClause = 'WHERE chat_id IS NOT NULL';
  let params = [];
  if (searchValue) {
    whereClause += ' AND (CAST(chat_id AS TEXT) LIKE ? OR first_name LIKE ? OR username LIKE ?)';
    params.push(`%${searchValue}%`, `%${searchValue}%`, `%${searchValue}%`);
  }
  
  try {
    const totalRecords = await new Promise((resolve, reject) => {
      d.get(`SELECT COUNT(*) as total FROM admins ${whereClause}`, params, (err, row) => {
        if (err) return reject(err);
        resolve(row.total);
      });
    });

    const adminsSQL = `
      SELECT chat_id, first_name, username
      FROM admins
      ${whereClause}
      ORDER BY chat_id
      LIMIT ? OFFSET ?`;

    const queryParams = [...params, length, start];
    const rows = await new Promise((resolve, reject) => {
      d.all(adminsSQL, queryParams, (err, r) => {
        if (err) return reject(err);
        resolve(r);
      });
    });

    for (const r of rows) {
      if (!(r.first_name && r.first_name.trim()) || !(r.username && r.username.trim())) {
        const info = await fetchAndCacheTgAdminInfo(r.chat_id);
        if (!r.first_name) r.first_name = info.first_name;
        if (!r.username) r.username = info.username;
      }
    }

    res.json({ draw, recordsTotal: totalRecords, recordsFiltered: totalRecords, data: rows });
  } catch (err) {
    console.error('Error loading TG admins:', err);
    return res.status(500).json({ error: err.message });
  }
});

// AJAX endpoint для серверной пагинации веб-админов
router.get('/web-data', (req, res) => {
  const d = db();
  
  // Параметры DataTables
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';
  
  // Строим WHERE условие для поиска
  let whereClause = '';
  let params = [];
  if (searchValue) {
    whereClause = 'WHERE username LIKE ? OR role LIKE ?';
    params.push(`%${searchValue}%`, `%${searchValue}%`);
  }
  
  // Получаем общее количество записей
  const countSQL = `SELECT COUNT(*) as total FROM web_admins ${whereClause}`;
  
  d.get(countSQL, params, (err, countResult) => {
    if (err) {
      console.error('Error counting web admins:', err);
      return res.status(500).json({ error: err.message });
    }
    
    const totalRecords = countResult.total;
    
    // Получаем данные для текущей страницы
    const webAdminsSQL = `
      SELECT username, role, profile_picture
      FROM web_admins 
      ${whereClause}
      ORDER BY username
      LIMIT ? OFFSET ?
    `;
    
    const queryParams = [...params, length, start];
    
    d.all(webAdminsSQL, queryParams, (err, rows) => {
      if (err) {
        console.error('Error loading web admins:', err);
        return res.status(500).json({ error: err.message });
      }
      
      res.json({
        draw: draw,
        recordsTotal: totalRecords,
        recordsFiltered: totalRecords,
        data: rows
      });
    });
  });
});

// Add TG admin
router.post('/', upload.none(), (req, res) => {
  const id = Number(req.body.chat_id);
  if (!id) {
    // Проверяем тип запроса для AJAX поддержки
    const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                   req.headers.accept && req.headers.accept.includes('application/json');
    
    if (isAjax) {
      return res.status(400).json({ success: false, message: 'Некорректный ID чата' });
    } else {
      return res.redirect('/admins');
    }
  }
  
  const d = db();
  d.run('INSERT OR IGNORE INTO admins(chat_id) VALUES (?)', [id], function(err) {
    if (err) {
      console.error('Error adding TG admin:', err);
      // Проверяем тип запроса для AJAX поддержки
      const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                     req.headers.accept && req.headers.accept.includes('application/json');
      
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка добавления администратора' });
      } else {
        return res.redirect('/admins');
      }
    }
    
    // Проверяем тип запроса для AJAX поддержки
    const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                   req.headers.accept && req.headers.accept.includes('application/json');
    
    if (isAjax) {
      res.json({ success: true, message: `Telegram администратор #${id} успешно добавлен` });
    } else {
    res.redirect('/admins');
    }
  });
});

// Delete TG admin
router.post('/delete/:id', (req, res) => {
  const id = Number(req.params.id);
  const d = db();
  
  // Проверяем тип запроса для AJAX поддержки
  const isAjax = req.headers['content-type'] === 'application/json' || 
                 req.headers.accept && req.headers.accept.includes('application/json');
  
  d.run('DELETE FROM admins WHERE chat_id = ?', [id], function(err) {
    if (err) {
      console.error('Error deleting Telegram admin:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка удаления администратора' });
      } else {
        return res.redirect('/admins');
      }
    }
    
    if (isAjax) {
      res.json({ success: true, message: `Telegram администратор #${id} успешно удален` });
    } else {
      res.redirect('/admins');
    }
  });
});

// Add / replace web admin (requires super)
router.post('/web', requireSuper, upload.single('profile_picture'), (req, res) => {
  const { username, password, role } = req.body;
  if (!(username && password)) {
    // Проверяем тип запроса для AJAX поддержки
    const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                   req.headers.accept && req.headers.accept.includes('application/json');
    
    if (isAjax) {
      return res.status(400).json({ success: false, message: 'Требуются имя пользователя и пароль' });
    } else {
      return res.redirect('/admins');
    }
  }
  
  const r = ['super', 'admin', 'guest'].includes(role) ? role : 'admin';
  
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) {
      console.error('Error hashing password:', err);
      // Проверяем тип запроса для AJAX поддержки
      const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                     req.headers.accept && req.headers.accept.includes('application/json');
      
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка при создании пароля' });
      } else {
        return res.status(500).send(err.message);
      }
    }
    
    const d = db();
    let sql, params;
    
    if (req.file) {
      // Если загружена аватарка, добавляем её в запрос
      const relPath = '/uploads/avatars/' + req.file.filename;
      sql = 'INSERT OR REPLACE INTO web_admins(username, password, role, profile_picture) VALUES (?, ?, ?, ?)';
      params = [username, hash, r, relPath];
    } else {
      // Без аватарки
      sql = 'INSERT OR REPLACE INTO web_admins(username, password, role) VALUES (?, ?, ?)';
      params = [username, hash, r];
    }
    
    d.run(sql, params, function(dbErr) {
      if (dbErr) {
        console.error('Error adding web admin:', dbErr);
        // Проверяем тип запроса для AJAX поддержки
        const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                       req.headers.accept && req.headers.accept.includes('application/json');
        
        if (isAjax) {
          return res.status(500).json({ success: false, message: 'Ошибка добавления веб-администратора' });
        } else {
          return res.redirect('/admins');
        }
      }
      
      // Проверяем тип запроса для AJAX поддержки
      const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                     req.headers.accept && req.headers.accept.includes('application/json');
      
      if (isAjax) {
        res.json({ success: true, message: `Веб-администратор "${username}" успешно добавлен` });
      } else {
      res.redirect('/admins');
      }
    });
  });
});

// Update existing web admin (requires super)
router.post('/web-update/:old', requireSuper, upload.single('profile_picture'), (req, res) => {
  const old = req.params.old;
  const { username: newUser, password, role } = req.body;
  if (!newUser) {
    // Проверяем тип запроса для AJAX поддержки
    const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                   req.headers.accept && req.headers.accept.includes('application/json');
    
    if (isAjax) {
      return res.status(400).json({ success: false, message: 'Требуется имя пользователя' });
    } else {
      return res.redirect('/admins');
    }
  }
  const newRole = ['admin', 'guest', 'super'].includes(role) ? role : 'admin';
  const d = db();

  // Fetch current profile picture to possibly delete later
  d.get('SELECT profile_picture FROM web_admins WHERE username = ?', [old], (selErr, row) => {
    if (selErr) {
      console.error('Error fetching web admin for update:', selErr);
      // Проверяем тип запроса для AJAX поддержки
      const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                     req.headers.accept && req.headers.accept.includes('application/json');
      
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка поиска администратора' });
      } else {
        return res.status(500).send(selErr.message);
      }
    }

    const currentPic = row ? row.profile_picture : null;

    const finish = (hash) => {
      const queryParts = ['username = ?', 'role = ?'];
      const params = [newUser, newRole];

      if (hash) {
        queryParts.push('password = ?');
        params.push(hash);
      }

      if (req.file) {
        const relPath = '/uploads/avatars/' + req.file.filename;
        queryParts.push('profile_picture = ?');
        params.push(relPath);

        // Remove old picture if exists and different
        if (currentPic && currentPic !== relPath) {
          const oldPath = path.join(__dirname, '..', '..', '..', currentPic);
          if (fs.existsSync(oldPath)) fs.unlink(oldPath, () => {});
        }
      }

      params.push(old); // WHERE username = ?
      const sql = `UPDATE web_admins SET ${queryParts.join(', ')} WHERE username = ?`;
      d.run(sql, params, function(updateErr) {
        if (updateErr) {
          console.error('Error updating web admin:', updateErr);
          // Проверяем тип запроса для AJAX поддержки
          const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                         req.headers.accept && req.headers.accept.includes('application/json');
          
          if (isAjax) {
            return res.status(500).json({ success: false, message: 'Ошибка обновления веб-администратора' });
          } else {
            return res.redirect('/admins');
          }
        }
        
        // Проверяем тип запроса для AJAX поддержки
        const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                       req.headers.accept && req.headers.accept.includes('application/json');
        
        if (isAjax) {
          res.json({ success: true, message: `Веб-администратор "${newUser}" успешно обновлен` });
        } else {
          res.redirect('/admins');
        }
      });
    };

    if (password) {
      bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
          console.error('Error hashing password for update:', err);
          // Проверяем тип запроса для AJAX поддержки
          const isAjax = req.headers['content-type'] && req.headers['content-type'].includes('multipart/form-data') ||
                         req.headers.accept && req.headers.accept.includes('application/json');
          
          if (isAjax) {
            return res.status(500).json({ success: false, message: 'Ошибка при создании пароля' });
          } else {
            return res.status(500).send(err.message);
          }
        }
        finish(hash);
      });
    } else {
      finish();
    }
  });
});

// Delete web admin (requires super)
router.post('/delete-web/:username', requireSuper, (req, res) => {
  const username = req.params.username;
  const d = db();
  
  // Проверяем тип запроса для AJAX поддержки
  const isAjax = req.headers['content-type'] === 'application/json' || 
                 req.headers.accept && req.headers.accept.includes('application/json');
  
  // Сначала получаем информацию об аватарке для удаления файла
  d.get('SELECT profile_picture FROM web_admins WHERE username = ?', [username], (err, row) => {
    if (err) {
      console.error('Error fetching admin for deletion:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка при удалении администратора' });
      } else {
        return res.redirect('/admins');
      }
    }
    
    // Удаляем запись из базы данных
    d.run('DELETE FROM web_admins WHERE username = ?', [username], function(deleteErr) {
      if (deleteErr) {
        console.error('Error deleting web admin:', deleteErr);
        if (isAjax) {
          return res.status(500).json({ success: false, message: 'Ошибка удаления администратора' });
        } else {
          return res.redirect('/admins');
        }
      }
      
      // Удаляем файл аватарки если он существует
      if (row && row.profile_picture) {
        const picPath = path.join(__dirname, '..', '..', '..', row.profile_picture);
        if (fs.existsSync(picPath)) {
          fs.unlink(picPath, (unlinkErr) => {
            if (unlinkErr) console.error('Error deleting avatar file:', unlinkErr);
          });
        }
      }
      
      if (isAjax) {
        res.json({ success: true, message: `Веб-администратор "${username}" успешно удален` });
      } else {
        res.redirect('/admins');
      }
    });
  });
});

module.exports = router; 