const express = require('express');
const router = express.Router();
const TelegramBot = require('node-telegram-bot-api');
const multer = require('multer');
const upload = multer();

const { db: sharedDb, DEFAULT_TZ, DEFAULT_DAILY_TIME } = require('../../core/db');

function db() { return sharedDb; }

// Создаем singleton-инстанс без polling (только для запросов к API)
let tgBot = null;
function getBot() {
  if (!tgBot) {
    tgBot = new TelegramBot(process.env.BOT_TOKEN, { polling: false });
  }
  return tgBot;
}

// Получить basic info пользователя у Telegram и закешировать в БД
async function fetchAndCacheUserInfo(chatId) {
  try {
    const bot = getBot();
    const chat = await bot.getChat(chatId);
    const firstName = chat.first_name || '';
    const username = chat.username || '';
    const d = db();
    d.run('UPDATE users SET first_name = ?, username = ? WHERE chat_id = ?', [firstName, username, chatId]);
    return { first_name: firstName, username };
  } catch (err) {
    console.warn('[TG] fetch error for', chatId, err.message);
    return { first_name: '', username: '' };
  }
}

// List users
router.get('/', (req, res) => {
    res.render('users', { 
      title: 'Пользователи', 
    rows: [], // Пустой массив, данные будут загружаться через AJAX
      DEFAULT_TZ, 
      DEFAULT_DAILY_TIME,
      useDataTables: true,
      styles: ['action-buttons.css']
  });
});

// AJAX endpoint для серверной пагинации
router.get('/data', async (req, res) => {
  const d = db();
  
  // Параметры DataTables
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';
  
  // Строим WHERE условие для поиска
  let whereClause = `WHERE CAST(chat_id AS TEXT) LIKE ?
                    OR timezone LIKE ?
                    OR daily_time LIKE ?
                    OR first_name LIKE ?
                    OR username LIKE ?`;
  let params = [
    `%${searchValue}%`, `%${searchValue}%`, `%${searchValue}%`,
    `%${searchValue}%`, `%${searchValue}%`
  ];
  
  try {
    const countSQL = `SELECT COUNT(*) as total FROM users ${whereClause}`;
    const totalRecords = await new Promise((resolve, reject) => {
      d.get(countSQL, params, (err, row) => {
        if (err) return reject(err);
        resolve(row.total);
      });
    });

    // Получаем данные для текущей страницы
    const usersSQL = `
      SELECT chat_id, first_name, username, timezone, daily_time, subscribed, last_daily_sent
      FROM users 
      ${whereClause}
      ORDER BY chat_id
      LIMIT ? OFFSET ?
    `;

    const queryParams = [...params, length, start];

    const rows = await new Promise((resolve, reject) => {
      d.all(usersSQL, queryParams, (err, r) => {
        if (err) return reject(err);
        resolve(r);
      });
    });

    // Автоматически запрашиваем недостающую информацию из Telegram
    for (const r of rows) {
      if (!(r.first_name && r.first_name.trim()) || !(r.username && r.username.trim())) {
        const info = await fetchAndCacheUserInfo(r.chat_id);
        if (!r.first_name) r.first_name = info.first_name;
        if (!r.username) r.username = info.username;
      }
    }

    const formattedRows = rows.map(row => ({
      chat_id: row.chat_id,
      first_name: row.first_name || '-',
      username: row.username || '-',
      timezone: row.timezone,
      daily_time: row.daily_time,
      subscribed: row.subscribed,
      last_daily_sent: row.last_daily_sent || '-'
    }));

    res.json({
      draw: draw,
      recordsTotal: totalRecords,
      recordsFiltered: totalRecords,
      data: formattedRows
    });
  } catch (err) {
    console.error('Error loading users:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Add user manually
router.post('/', (req, res) => {
  const chatId = Number(req.body.chat_id);
  const tz = req.body.timezone || DEFAULT_TZ;
  const time = req.body.daily_time || DEFAULT_DAILY_TIME;
  if (!chatId) return res.redirect('/users');
  const d = db();
  d.run('INSERT OR IGNORE INTO users(chat_id, timezone, daily_time) VALUES (?, ?, ?)', [chatId, tz, time], () => {
    res.redirect('/users');
  });
});

// Update user
router.post('/update/:id', upload.none(), (req, res) => {
  const id = Number(req.params.id);
  let { timezone, daily_time, subscribed } = req.body;
  // Если поля пусты, используем значения по умолчанию
  timezone = (timezone && timezone.trim()) ? timezone.trim() : DEFAULT_TZ;
  daily_time = (daily_time && daily_time.trim()) ? daily_time.trim() : DEFAULT_DAILY_TIME;
  const sub = subscribed ? 1 : 0;
  const d = db();

  // Определяем, является ли запрос AJAX (fetch)
  const isAjax = req.headers['x-requested-with'] === 'XMLHttpRequest' ||
                 (req.headers.accept && req.headers.accept.includes('application/json'));

  d.run('UPDATE users SET timezone = ?, daily_time = ?, subscribed = ?, daily_enabled = ?, broadcast_enabled = ? WHERE chat_id = ?', [timezone, daily_time, sub, sub, sub, id], function(err) {
    if (err) {
      console.error('Error updating user:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка обновления пользователя' });
      }
      return res.redirect('/users');
    }

    if (isAjax) {
      return res.json({ success: true, message: `Пользователь #${id} обновлён` });
    }

    res.redirect('/users');
  });
});

// Delete user
router.post('/delete/:id', (req, res) => {
  const id = Number(req.params.id);
  const d = db();
  
  // Проверяем тип запроса для AJAX поддержки
  const isAjax = req.headers['content-type'] === 'application/json' || 
                 req.headers.accept && req.headers.accept.includes('application/json');
  
  d.run('DELETE FROM users WHERE chat_id = ?', [id], function(err) {
    if (err) {
      console.error('Error deleting user:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка удаления пользователя' });
      } else {
        return res.redirect('/users');
      }
    }
    
    if (isAjax) {
      res.json({ success: true, message: `Пользователь #${id} успешно удален` });
    } else {
      res.redirect('/users');
    }
  });
});

// ------------------ GROUPS MANAGEMENT ------------------

// Create new group from selected users
router.post('/create-group', upload.none(), async (req, res) => {
  // Гарантируем, что необходимые таблицы существуют (на случай, если приложение не перезапускалось после обновления)
  const d = db();
  await new Promise(resolve=>d.serialize(()=>{
    d.run(`CREATE TABLE IF NOT EXISTS groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );`);
    d.run(`CREATE TABLE IF NOT EXISTS group_members (
      group_id INTEGER NOT NULL,
      chat_id INTEGER NOT NULL,
      PRIMARY KEY (group_id, chat_id),
      FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY (chat_id) REFERENCES users(chat_id) ON DELETE CASCADE
    );`, resolve);
  }));

  const { name, members } = req.body;
  if (!name || !members) {
    return res.status(400).json({ success: false, message: 'Недостаточно данных для создания группы' });
  }
  // members может быть JSON массивом или CSV строкой
  let memberIds = [];
  try {
    if (Array.isArray(members)) {
      memberIds = members.map((id) => Number(id)).filter((n) => n);
    } else if (typeof members === 'string') {
      memberIds = members.split(',').map((s) => Number(s.trim())).filter((n) => n);
    }
  } catch (e) {
    return res.status(400).json({ success: false, message: 'Неверный формат участников' });
  }
  if (memberIds.length === 0) {
    return res.status(400).json({ success: false, message: 'Не выбраны пользователи' });
  }
  const now = new Date().toISOString();
  try {
    await new Promise((resolve, reject) => {
      d.run('INSERT INTO groups(name, created_at) VALUES(?, ?)', [name, now], function(err) {
        if (err) {
          if(err.message && err.message.includes('UNIQUE')){
            return reject(new Error('Группа с таким названием уже существует'));
          }
          return reject(err);
        }
        const groupId = this.lastID;
        const stmt = d.prepare('INSERT OR IGNORE INTO group_members(group_id, chat_id) VALUES(?, ?)');
        memberIds.forEach((cid) => stmt.run([groupId, cid]));
        stmt.finalize((finErr) => {
          if (finErr) return reject(finErr);
          resolve();
        });
      });
    });
    return res.json({ success: true });
  } catch (err) {
    console.error('[GROUPS] Error creating group:', err);
    return res.status(500).json({ success: false, message: err.message || 'Ошибка создания группы' });
  }
});

// Data endpoint for groups list (server-side compatible)
router.get('/groups-data', async (req, res) => {
  const d = db();
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';

  let whereClause = 'WHERE name LIKE ?';
  const params = [`%${searchValue}%`];

  try {
    const totalSQL = `SELECT COUNT(*) as total FROM groups ${whereClause}`;
    const totalRecords = await new Promise((resolve, reject) => {
      d.get(totalSQL, params, (err, row) => {
        if (err) return reject(err);
        resolve(row.total);
      });
    });

    const groupsSQL = `
      SELECT g.id, g.name,
        (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) AS members_count
      FROM groups g
      ${whereClause}
      ORDER BY g.id
      LIMIT ? OFFSET ?`;
    const queryParams = [...params, length, start];
    const rows = await new Promise((resolve, reject) => {
      d.all(groupsSQL, queryParams, (err, r) => {
        if (err) return reject(err);
        resolve(r);
      });
    });

    res.json({
      draw,
      recordsTotal: totalRecords,
      recordsFiltered: totalRecords,
      data: rows
    });
  } catch (err) {
    console.error('[GROUPS] Error loading groups:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Delete group
router.post('/groups/delete/:id', async (req, res) => {
  const id = Number(req.params.id);
  const d = db();
  const isAjax = req.headers['content-type'] === 'application/json' ||
                 (req.headers.accept && req.headers.accept.includes('application/json'));
  d.run('DELETE FROM groups WHERE id = ?', [id], function(err) {
    if (err) {
      console.error('[GROUPS] Error deleting group:', err);
      if (isAjax) return res.status(500).json({ success: false, message: 'Ошибка удаления группы' });
      return res.redirect('/users');
    }
    if (isAjax) {
      res.json({ success: true, message: `Группа #${id} удалена` });
    } else {
      res.redirect('/users');
    }
  });
});

// --- Получить участников группы (JSON)
router.get('/groups/:id/members', async (req,res)=>{
  const groupId = Number(req.params.id);
  const d=db();
  d.all('SELECT chat_id FROM group_members WHERE group_id = ?', [groupId], (err, rows)=>{
    if(err){
      console.error('[GROUPS] members fetch err',err);
      return res.status(500).json({success:false,error:'DB error'});
    }
    const list = rows.map(r=>r.chat_id);
    res.json({success:true, members:list});
  });
});

// --- Обновить участников группы
router.post('/groups/update/:id', upload.none(), async (req,res)=>{
  const groupId = Number(req.params.id);
  let { members } = req.body;
  if(!members) return res.status(400).json({success:false, message:'Нет участников'});
  if(typeof members==='string'){
    members = members.split(/[,\s]+/).filter(Boolean);
  }
  const ids = members.map(n=>Number(n)).filter(n=>n);
  const d=db();
  try{
    await new Promise((resolve,reject)=>{
      d.serialize(()=>{
        d.run('DELETE FROM group_members WHERE group_id = ?', [groupId]);
        const stmt=d.prepare('INSERT OR IGNORE INTO group_members(group_id, chat_id) VALUES(?,?)');
        ids.forEach(cid=> stmt.run([groupId,cid]));
        stmt.finalize(err=>err?reject(err):resolve());
      });
    });
    res.json({success:true});
  }catch(err){
    console.error('[GROUPS] update members error',err);
    res.status(500).json({success:false,message:'Ошибка сохранения'});
  }
});

module.exports = router; 