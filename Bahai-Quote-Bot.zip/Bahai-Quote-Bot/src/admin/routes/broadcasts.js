const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const { DateTime } = require('luxon');
const { db: sharedDb, DEFAULT_TZ } = require('../../core/db');
const { gptGenerate } = require('../../bot/gpt');
const timeManager = require('../../core/timeUtils');

// Helper to access shared sqlite instance
function db() {
  return sharedDb;
}

// Папка для изображений рассылок
const broadcastDir = path.join(__dirname, '..', '..', '..', 'uploads', 'broadcasts');
if (!fs.existsSync(broadcastDir)) {
  fs.mkdirSync(broadcastDir, { recursive: true });
}

// Конфигурация загрузчика
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, broadcastDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `broadcast_${Date.now()}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  if (allowed.includes(file.mimetype)) cb(null, true); else cb(new Error('Invalid file type'));
}

const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 }, fileFilter });

// Утилита для извлечения content из возможного JSON ответа OpenAI
function sanitizeText(raw){
  if(!raw) return '';
  if(typeof raw === 'string'){
    const trimmed = raw.trim();
    if(trimmed.startsWith('{')){
      try{
        const obj = JSON.parse(trimmed);
        const content = obj?.choices?.[0]?.message?.content;
        if(content) return content.trim();
      }catch{}
    }
    return trimmed;
  }
  if(typeof raw === 'object'){
    try{
      const content = raw?.choices?.[0]?.message?.content;
      if(content) return content.trim();
      return JSON.stringify(raw);
    }catch{
      return String(raw);
    }
  }
  return String(raw);
}

// ================= MARKUP HELPERS =================
function pushModalMarkup() {
  return `
<div class="modal fade" id="newPushModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" action="/broadcasts/push">
        <div class="modal-header"><h5 class="modal-title"><i class="bi bi-send-plus-fill me-2"></i>Новая PUSH рассылка</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="row g-2 mb-3">
            <div class="col-md-6"><label class="form-label"><i class="bi bi-calendar-date me-1"></i>Дата</label><input type="date" name="date" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label"><i class="bi bi-clock me-1"></i>Время</label><input type="time" name="time" class="form-control" required></div>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" value="1" id="pushSendNow" name="send_now">
            <label class="form-check-label" for="pushSendNow"><i class="bi bi-broadcast me-1"></i>Отправить немедленно</label>
          </div>
          <script>
            document.addEventListener('DOMContentLoaded',function(){
              const chk=document.getElementById('pushSendNow');
              if(!chk)return;
              const dateFld=document.querySelector('#newPushModal input[name="date"]');
              const timeFld=document.querySelector('#newPushModal input[name="time"]');
              function toggleFields(){
                const disabled=chk.checked;
                dateFld.required=!disabled;
                timeFld.required=!disabled;
                dateFld.disabled=disabled;
                timeFld.disabled=disabled;
                if(disabled){
                  const now=new Date();
                  dateFld.value=now.toISOString().slice(0,10);
                  timeFld.value=now.toTimeString().slice(0,5);
                }
              }
              chk.addEventListener('change',toggleFields);
            });
          </script>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-chat-left-text me-1"></i>Сообщение</label>
            <textarea name="message" class="form-control" rows="4" placeholder="Введите текст сообщения для рассылки..."></textarea>
          </div>
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" value="1" id="pushUseGpt" name="use_gpt">
            <label class="form-check-label" for="pushUseGpt"><i class="bi bi-robot me-1"></i>Сгенерировать текст через ChatGPT</label>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-card-text me-1"></i>Промпт для ChatGPT (опционально)</label>
            <textarea name="gpt_prompt" class="form-control" rows="3" placeholder="Если пусто, используется промпт по умолчанию..."></textarea>
          </div>
          <div>
            <label class="form-label"><i class="bi bi-image me-1"></i>Ссылка/ID картинки (опционально)</label>
            <div class="input-group mb-2">
              <input type="text" name="image" class="form-control image-input" placeholder="URL изображения или Telegram File ID" data-preview="pushPreview" />
              <button type="button" class="btn btn-outline-secondary image-clear" title="Очистить поле"><i class="bi bi-x-lg"></i></button>
            </div>
            <div class="image-preview" id="pushPreview" style="display: none;">
              <div class="border rounded p-2 bg-light text-center" style="max-width: 200px; margin: 0 auto;">
                <img class="img-fluid preview-img" style="max-height: 120px; object-fit: contain;" />
                <div class="mt-1">
                  <small class="text-muted">Предпросмотр</small>
                </div>
              </div>
            </div>
            <div class="form-text">
              <i class="bi bi-info-circle me-1"></i>Поддерживаются: HTTP/HTTPS ссылки или Telegram File ID
            </div>
          </div>
          <script>
            document.addEventListener('DOMContentLoaded',function(){
              const gptCheck=document.getElementById('pushUseGpt');
              const msgField=document.querySelector('#newPushModal textarea[name="message"]');
              if(gptCheck&&msgField){
                function toggleMessage(){
                  msgField.disabled=gptCheck.checked;
                  if(gptCheck.checked){
                    msgField.placeholder='Сообщение будет сгенерировано через ChatGPT';
                    msgField.classList.add('bg-light');
                  }else{
                    msgField.placeholder='Введите текст сообщения для рассылки...';
                    msgField.classList.remove('bg-light');
                  }
                }
                gptCheck.addEventListener('change',toggleMessage);
                toggleMessage();
              }
            });
          </script>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary enhanced-btn" data-bs-dismiss="modal">Отмена</button><button type="submit" class="btn btn-primary enhanced-btn"><i class="bi bi-plus-circle-fill"></i>Добавить</button></div>
      </form>
    </div>
  </div>
</div>`;
}

function weeklyModalMarkup() {
  return `
<div class="modal fade" id="newWeeklyModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" action="/broadcasts/weekly">
        <div class="modal-header"><h5 class="modal-title"><i class="bi bi-calendar-week-fill me-2"></i>Новая Weekly рассылка</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label"><i class="bi bi-calendar-day me-1"></i>День недели</label>
              <select name="day" class="form-select">
                <option value="1">Понедельник</option><option value="2">Вторник</option><option value="3">Среда</option><option value="4">Четверг</option><option value="5">Пятница</option><option value="6">Суббота</option><option value="7">Воскресенье</option>
              </select>
            </div>
            <div class="col-md-6"><label class="form-label"><i class="bi bi-clock me-1"></i>Время</label><input type="time" name="time" class="form-control" required></div>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-chat-left-text me-1"></i>Сообщение</label>
            <textarea name="message" class="form-control" rows="4" placeholder="Введите текст сообщения для рассылки..."></textarea>
          </div>
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" value="1" id="weeklyUseGpt" name="use_gpt">
            <label class="form-check-label" for="weeklyUseGpt"><i class="bi bi-robot me-1"></i>Сгенерировать текст через ChatGPT (каждую неделю будет новый)</label>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-card-text me-1"></i>Промпт для ChatGPT (опционально)</label>
            <textarea name="gpt_prompt" class="form-control" rows="3" placeholder="Если пусто, используется промпт по умолчанию..."></textarea>
          </div>
          <div>
            <label class="form-label"><i class="bi bi-image me-1"></i>Ссылка/ID картинки (опционально)</label>
            <div class="input-group mb-2">
              <input type="text" name="image" class="form-control image-input" placeholder="URL изображения или Telegram File ID" data-preview="weeklyPreview" />
              <button type="button" class="btn btn-outline-secondary image-clear" title="Очистить поле"><i class="bi bi-x-lg"></i></button>
            </div>
            <div class="image-preview" id="weeklyPreview" style="display: none;">
              <div class="border rounded p-2 bg-light text-center" style="max-width: 200px; margin: 0 auto;">
                <img class="img-fluid preview-img" style="max-height: 120px; object-fit: contain;" />
                <div class="mt-1">
                  <small class="text-muted">Предпросмотр</small>
                </div>
              </div>
            </div>
            <div class="form-text">
              <i class="bi bi-info-circle me-1"></i>Поддерживаются: HTTP/HTTPS ссылки или Telegram File ID
            </div>
          </div>
          <script>
            document.addEventListener('DOMContentLoaded',function(){
              const gptCheck=document.getElementById('weeklyUseGpt');
              const msgField=document.querySelector('#newWeeklyModal textarea[name="message"]');
              if(gptCheck&&msgField){
                function toggleMessage(){
                  msgField.disabled=gptCheck.checked;
                  if(gptCheck.checked){
                    msgField.placeholder='Сообщение будет сгенерировано через ChatGPT каждую неделю';
                    msgField.classList.add('bg-light');
                  }else{
                    msgField.placeholder='Введите текст сообщения для рассылки...';
                    msgField.classList.remove('bg-light');
                  }
                }
                gptCheck.addEventListener('change',toggleMessage);
                toggleMessage();
              }
            });
          </script>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary enhanced-btn" data-bs-dismiss="modal">Отмена</button><button type="submit" class="btn btn-primary enhanced-btn"><i class="bi bi-plus-circle-fill"></i>Добавить</button></div>
      </form>
    </div>
  </div>
</div>`;
}

function dailyModalMarkup() {
  return `
<div class="modal fade" id="newDailyModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" action="/broadcasts/daily">
        <div class="modal-header"><h5 class="modal-title"><i class="bi bi-calendar-day-fill me-2"></i>Новая Daily рассылка</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="row g-2 mb-3">
            <div class="col"><label class="form-label"><i class="bi bi-clock me-1"></i>Время</label><input type="time" name="time" class="form-control" required></div>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-chat-left-text me-1"></i>Сообщение</label>
            <textarea name="message" class="form-control" rows="4" placeholder="Введите текст сообщения для рассылки..."></textarea>
          </div>
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" value="1" id="dailyUseGpt" name="use_gpt">
            <label class="form-check-label" for="dailyUseGpt"><i class="bi bi-robot me-1"></i>Сгенерировать текст через ChatGPT (каждый день будет новый)</label>
          </div>
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-card-text me-1"></i>Промпт для ChatGPT (опционально)</label>
            <textarea name="gpt_prompt" class="form-control" rows="3" placeholder="Если пусто, используется промпт по умолчанию..."></textarea>
          </div>
          <div>
            <label class="form-label"><i class="bi bi-image me-1"></i>Ссылка/ID картинки (опционально)</label>
            <div class="input-group mb-2">
              <input type="text" name="image" class="form-control image-input" placeholder="URL изображения или Telegram File ID" data-preview="dailyPreview" />
              <button type="button" class="btn btn-outline-secondary image-clear" title="Очистить поле"><i class="bi bi-x-lg"></i></button>
            </div>
            <div class="image-preview" id="dailyPreview" style="display: none;">
              <div class="border rounded p-2 bg-light text-center" style="max-width: 200px; margin: 0 auto;">
                <img class="img-fluid preview-img" style="max-height: 120px; object-fit: contain;" />
                <div class="mt-1">
                  <small class="text-muted">Предпросмотр</small>
                </div>
              </div>
            </div>
            <div class="form-text">
              <i class="bi bi-info-circle me-1"></i>Поддерживаются: HTTP/HTTPS ссылки или Telegram File ID
            </div>
          </div>
          <script>
            document.addEventListener('DOMContentLoaded',function(){
              const gptCheck=document.getElementById('dailyUseGpt');
              const msgField=document.querySelector('#newDailyModal textarea[name="message"]');
              if(gptCheck&&msgField){
                function toggleMessage(){
                  msgField.disabled=gptCheck.checked;
                  if(gptCheck.checked){
                    msgField.placeholder='Сообщение будет сгенерировано через ChatGPT каждый день';
                    msgField.classList.add('bg-light');
                  }else{
                    msgField.placeholder='Введите текст сообщения для рассылки...';
                    msgField.classList.remove('bg-light');
                  }
                }
                gptCheck.addEventListener('change',toggleMessage);
                toggleMessage();
              }
            });
          </script>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary enhanced-btn" data-bs-dismiss="modal">Отмена</button><button type="submit" class="btn btn-primary enhanced-btn"><i class="bi bi-plus-circle-fill"></i>Добавить</button></div>
      </form>
    </div>
  </div>
</div>`;
}

function imgModalMarkup() {
  return `
<div class="modal fade" id="imgModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" id="imgForm" action="">
        <div class="modal-header"><h5 class="modal-title"><i class="bi bi-image-fill me-2"></i>Изображение рассылки</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <label class="form-label">URL или FileID изображения</label>
          <div class="input-group mb-2">
            <input type="text" name="image" id="imgInput" class="form-control image-input" placeholder="Вставьте URL или Telegram File ID" data-preview="imgModalPreview" />
            <button type="button" class="btn btn-outline-secondary image-clear" id="imgClearBtn" title="Очистить поле"><i class="bi bi-x-lg"></i></button>
            <a id="imgOpen" class="btn btn-outline-secondary" href="#" target="_blank" style="display:none;" title="Открыть изображение в новой вкладке"><i class="bi bi-box-arrow-up-right"></i></a>
          </div>
          <div class="image-preview" id="imgModalPreview" style="display:none;">
            <div class="border rounded p-2 bg-light text-center" style="max-width:250px;margin:0 auto;">
              <img class="img-fluid preview-img" style="max-height:200px;object-fit:contain;" />
              <div class="mt-1"><small class="text-muted">Предпросмотр</small></div>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="submit" name="remove" value="1" class="btn btn-outline-danger enhanced-btn" title="Удалить изображение из этой рассылки"><i class="bi bi-trash-fill"></i>Удалить картинку</button>
          <div>
            <button type="button" class="btn btn-secondary enhanced-btn me-2" data-bs-dismiss="modal">Отмена</button>
            <button type="submit" class="btn btn-primary enhanced-btn"><i class="bi bi-save-fill"></i>Сохранить</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>`;
}

// ================= ROUTES =================
// List broadcasts
router.get('/', (req, res) => {
  res.render('broadcasts', {
    title: 'Рассылки',
    rows: [], // Пустой массив, данные будут загружаться через AJAX
    useDataTables: true,
    styles: ['table-image-preview.css', 'action-buttons.css', 'forms.css'],
    scripts: ['broadcasts.js']
  });
});

// AJAX endpoint для серверной пагинации
router.get('/data', (req, res) => {
  const d = db();
  
  // Параметры DataTables
  const draw = parseInt(req.query.draw) || 1;
  const start = parseInt(req.query.start) || 0;
  const length = parseInt(req.query.length) || 20;
  const searchValue = req.query.search ? req.query.search.value : '';
  
  // Строим WHERE условие для поиска
  let whereClause = '';
  let params = [];
  if (searchValue) {
    whereClause = 'WHERE message LIKE ? OR type LIKE ?';
    params.push(`%${searchValue}%`, `%${searchValue}%`);
  }
  
  // Получаем общее количество записей
  const countSQL = `SELECT COUNT(*) as total FROM broadcasts ${whereClause}`;
  
  d.get(countSQL, params, (err, countResult) => {
    if (err) {
      console.error('Error counting broadcasts:', err);
      return res.status(500).json({ error: err.message });
    }
    
    const totalRecords = countResult.total;
    
    // Получаем данные для текущей страницы
    const broadcastsSQL = `
      SELECT id, type, schedule, message, image, sent
      FROM broadcasts 
      ${whereClause}
      ORDER BY (type IN ("weekly", "daily")) DESC, CASE WHEN type="push" THEN datetime(schedule) END DESC, id DESC
      LIMIT ? OFFSET ?
    `;
    
    const queryParams = [...params, length, start];
    
    d.all(broadcastsSQL, queryParams, (err, rows) => {
      if (err) {
        console.error('Error loading broadcasts:', err);
        return res.status(500).json({ error: err.message });
      }
    
      // Форматируем данные для отправки
    const formattedRows = rows.map(row => {
      let formattedSchedule = row.schedule;
      
      if (row.type === 'push') {
        // Для PUSH рассылок schedule содержит ISO дату в UTC - форматируем в локальное время
        formattedSchedule = timeManager.formatForDisplay(row.schedule, 'dd.MM.yyyy HH:mm');
      } else if (row.type === 'weekly') {
        // Для weekly рассылок schedule в формате "day|time" (например "1|09:00")
        const [day, time] = row.schedule.split('|');
        const dayNames = ['', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
        formattedSchedule = `${dayNames[day]} в ${time}`;
      } else if (row.type === 'daily') {
        // Для daily рассылок schedule содержит только время (например "09:00")
        formattedSchedule = `Ежедневно в ${row.schedule}`;
      }
      
      // Если message случайно содержит полный JSON ответа OpenAI, извлекаем content
      let cleanMsg = row.message;
      if (typeof cleanMsg === 'string' && cleanMsg.trim().startsWith('{')) {
        try {
          const obj = JSON.parse(cleanMsg);
          const extracted = obj?.choices?.[0]?.message?.content;
          if (extracted) cleanMsg = extracted.trim();
        } catch(_) {}
      }
        
      return {
          id: row.id,
          type: row.type,
          schedule: formattedSchedule,
          originalSchedule: row.schedule, // Оригинальное расписание для JS
        message: cleanMsg,
          image: row.image || '',
          sent: row.sent,
          prio: row.type === 'weekly' ? 2 : (row.type === 'daily' ? 1 : 0)
      };
    });
    
      res.json({
        draw: draw,
        recordsTotal: totalRecords,
        recordsFiltered: totalRecords,
        data: formattedRows
      });
    });
  });
});

// Add PUSH broadcast
router.post('/push', upload.single('image_file'), async (req, res) => {
  const { date, time, message, image, use_gpt, gpt_prompt, send_now, targets } = req.body;
  const uploadedImage = req.file ? '/uploads/broadcasts/' + req.file.filename : null;
  // Валидация: если не выбрана немедленная отправка, требуем дату и время
  if (!send_now && !(date && time)) return res.redirect('/broadcasts');
  if (!(message || use_gpt)) return res.redirect('/broadcasts');

  const useGpt = use_gpt ? 1 : 0;
  const prompt = (gpt_prompt || '').trim() || 'Сгенерируй вдохновляющий пост для Telegram на основе цитат Баха\'и (до 400 символов)';

  let finalMsg = message;
  finalMsg = sanitizeText(finalMsg);
  if (useGpt) {
    try {
      finalMsg = sanitizeText(await gptGenerate(prompt));
    } catch (e) {
      console.error('[ADMIN] GPT error:', e);
      finalMsg = '(GPT error)';
    }
  }
  // Если выбран режим немедленной отправки, используем текущее UTC время
  let iso;
  if (send_now) {
    iso = DateTime.utc().toISO();
  } else {
    const localDt = DateTime.fromISO(`${date}T${time}`, { zone: DEFAULT_TZ });
    iso = localDt.isValid ? localDt.toUTC().toISO() : `${date}T${time}:00Z`;
  }
  const d = db();
  d.run('INSERT INTO broadcasts(type, schedule, message, image, use_gpt, gpt_prompt, targets) VALUES ("push", ?, ?, ?, ?, ?, ?)', [iso, finalMsg, uploadedImage || image || null, useGpt, prompt, targets || null], () => {
    // Проверяем AJAX
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'));
    if (isAjax) {
      return res.json({ success: true, message: 'Рассылка создана' });
    }
    res.redirect('/broadcasts');
  });
});

// Add WEEKLY broadcast
router.post('/weekly', upload.single('image_file'), async (req, res) => {
  const { day, time, message, image, use_gpt, gpt_prompt, targets } = req.body;
  const uploadedImage = req.file ? '/uploads/broadcasts/' + req.file.filename : null;
  if (!(day && time && (message || use_gpt))) return res.redirect('/broadcasts');

  const useGpt = use_gpt ? 1 : 0;
  const prompt = (gpt_prompt || '').trim() || 'Сгенерируй вдохновляющий пост для Telegram на основе цитат Баха\'и (до 400 символов)';

  let finalMsg = message;
  finalMsg = sanitizeText(finalMsg);
  if (useGpt) {
    try {
      finalMsg = sanitizeText(await gptGenerate(prompt));
    } catch (e) {
      console.error('[ADMIN] GPT error:', e);
      finalMsg = '(GPT error)';
    }
  }
  const sched = `${day}|${time}`;
  const d = db();
  d.run('INSERT INTO broadcasts(type, schedule, message, image, use_gpt, gpt_prompt, targets) VALUES ("weekly", ?, ?, ?, ?, ?, ?)', [sched, finalMsg, uploadedImage || image || null, useGpt, prompt, targets || null], () => {
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'));
    if (isAjax) {
      return res.json({ success: true });
    }
    res.redirect('/broadcasts');
  });
});

// Add DAILY broadcast
router.post('/daily', upload.single('image_file'), async (req, res) => {
  const { time, message, image, use_gpt, gpt_prompt, targets } = req.body;
  const uploadedImage = req.file ? '/uploads/broadcasts/' + req.file.filename : null;
  if (!(time && (message || use_gpt))) return res.redirect('/broadcasts');

  const useGpt = use_gpt ? 1 : 0;
  const prompt = (gpt_prompt || '').trim() || 'Сгенерируй вдохновляющий пост для Telegram на основе цитат Баха\'i (до 400 символов)';

  let finalMsg = message;
  finalMsg = sanitizeText(finalMsg);
  if (useGpt) {
    try {
      finalMsg = sanitizeText(await gptGenerate(prompt));
    } catch (e) {
      console.error('[ADMIN] GPT error:', e);
      finalMsg = '(GPT error)';
    }
  }
  const d = db();
  d.run('INSERT INTO broadcasts(type, schedule, message, image, use_gpt, gpt_prompt, targets) VALUES ("daily", ?, ?, ?, ?, ?, ?)', [time, finalMsg, uploadedImage || image || null, useGpt, prompt, targets || null], () => {
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'));
    if (isAjax) {
      return res.json({ success: true });
    }
    res.redirect('/broadcasts');
  });
});

// Update broadcast image
router.post('/update-image/:id', (req, res) => {
  const id = Number(req.params.id);
  let img = (req.body.image || '').trim();
  if (req.body.remove) img = null;
  const d = db();
  d.run('UPDATE broadcasts SET image = ? WHERE id = ?', [img || null, id], () => {
    res.redirect('/broadcasts');
  });
});

// Edit broadcast message
router.post('/edit/:id', (req, res) => {
  const id = Number(req.params.id);
  const message = (req.body.message || '').trim();
  if (!message) return res.redirect('/broadcasts');
  const d = db();
  d.run('UPDATE broadcasts SET message = ? WHERE id = ?', [message, id], () => {
    res.redirect('/broadcasts');
  });
});

// Delete broadcast
router.post('/delete/:id', (req, res) => {
  const id = Number(req.params.id);
  const d = db();
  
  // Проверяем тип запроса для AJAX поддержки
  const isAjax = req.headers['content-type'] === 'application/json' || 
                 req.headers.accept && req.headers.accept.includes('application/json');
  
  d.run('DELETE FROM broadcasts WHERE id = ?', [id], function(err) {
    if (err) {
      console.error('Error deleting broadcast:', err);
      if (isAjax) {
        return res.status(500).json({ success: false, message: 'Ошибка удаления рассылки' });
      } else {
        return res.redirect('/broadcasts');
      }
    }
    
    if (isAjax) {
      res.json({ success: true, message: `Рассылка #${id} успешно удалена` });
    } else {
      res.redirect('/broadcasts');
    }
  });
});

// Add GPT generation endpoint
router.post('/gpt', express.json(), async (req, res) => {
  // Принимаем промпт из тела запроса (JSON). Если пусто – используем дефолтный.
  const prompt = (req.body?.gpt_prompt || '').trim() || 'Сгенерируй вдохновляющий пост для Telegram на основе цитат Баха\'и (до 400 символов)';
  try {
    const message = sanitizeText(await gptGenerate(prompt));
    res.json({ success: true, message });
  } catch (e) {
    console.error('[ADMIN] GPT error:', e);
    res.status(500).json({ success: false, error: 'Ошибка генерации GPT' });
  }
});

// === Error handler for invalid file uploads ===
router.use((err, req, res, next) => {
  // Проверяем ошибку Multer о типе файла или размере
  if (err && (err.message === 'Invalid file type' || err.code === 'LIMIT_FILE_SIZE')) {
    console.error('[ADMIN] Upload error:', err.message);
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'));
    const friendly = err.message === 'Invalid file type' ?
      'Недопустимый формат файла. Разрешены JPEG, PNG, GIF, WEBP.' :
      'Размер файла превышает лимит 10MB.';
    if (isAjax) {
      return res.status(400).json({ success: false, message: friendly });
    }
    // Для обычного POST перенаправляем с параметром ?error=...
    const redirectUrl = req.get('referer') || '/broadcasts';
    return res.redirect(redirectUrl + '?error=' + encodeURIComponent(friendly));
  }
  // Если это не наша ошибка – передаём дальше
  next(err);
});

module.exports = router; 