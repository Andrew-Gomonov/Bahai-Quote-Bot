const express = require('express');
const router = express.Router();
const { db } = require('../../core/db');

// Ensure table exists
const ensureTable = () => {
  db.run(`CREATE TABLE IF NOT EXISTS support_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );`);
};

const DEFAULT_SETTINGS = {
  paypal_url: 'https://paypal.me/ANDREIGOMONOV?country.x=MD&locale.x=en_US',
  paypal_email: 'andrei.gomonov.md@gmail.com',
  card_number: '5397 0200 6559 1644',
  card_holder: 'ANDREI GOMONOV',
  mia_phone: '+373 76 713 853',
  mia_holder: 'ANDREI GOMONOV',
  github_url: 'https://github.com/Andrew-Gomonov/Bahai-Quote-Bot',
  telegram_username: '@bahai_md_bot',
  telegram_url: 'https://t.me/bahai_md_bot'
};

function getSettings(callback) {
  ensureTable();
  db.all('SELECT key, value FROM support_settings', (err, rows) => {
    if (err) return callback(err, DEFAULT_SETTINGS);
    const settings = { ...DEFAULT_SETTINGS };
    rows.forEach(r => { settings[r.key] = r.value; });
    callback(null, settings);
  });
}

function saveSettings(data, callback) {
  ensureTable();
  const stmt = db.prepare('INSERT OR REPLACE INTO support_settings(key, value) VALUES (?, ?)');
  db.serialize(() => {
    Object.entries(data).forEach(([k, v]) => {
      stmt.run(k, v);
    });
    stmt.finalize(callback);
  });
}

function isSuper(req) {
  return req.user && req.user.role === 'super';
}

// GET support page
router.get('/', (req, res) => {
  getSettings((err, settings) => {
    if (err) console.error('[SUPPORT] Error fetching settings:', err);
    res.render('support', {
      title: 'Поддержка проекта',
      user: req.user,
      styles: ['support.css'],
      settings
    });
  });
});

// Manage page (super admin only)
router.get('/manage', (req, res) => {
  if (!isSuper(req)) return res.status(403).render('error', { title: 'Запрещено', error: 'Доступ только для супер-администратора', code: 403 });
  getSettings((err, settings) => {
    if (err) settings = DEFAULT_SETTINGS;
    res.render('support_manage', {
      title: 'Редактировать страницу поддержки',
      user: req.user,
      styles: ['support.css'],
      settings,
      messages: req.flash()
    });
  });
});

router.post('/manage', (req, res) => {
  if (!isSuper(req)) return res.status(403).render('error', { title: 'Запрещено', error: 'Доступ только для супер-администратора', code: 403 });
  const data = {
    paypal_url: req.body.paypal_url || '',
    paypal_email: req.body.paypal_email || '',
    card_number: req.body.card_number || '',
    card_holder: req.body.card_holder || '',
    mia_phone: req.body.mia_phone || '',
    mia_holder: req.body.mia_holder || '',
    github_url: req.body.github_url || '',
    telegram_username: req.body.telegram_username || '',
    telegram_url: req.body.telegram_url || ''
  };
  saveSettings(data, (err) => {
    if (err) {
      console.error('[SUPPORT] Error saving settings:', err);
      req.flash('error', 'Не удалось сохранить настройки');
    } else {
      req.flash('success', 'Настройки успешно сохранены');
    }
    res.redirect('/support/manage');
  });
});

module.exports = router; 