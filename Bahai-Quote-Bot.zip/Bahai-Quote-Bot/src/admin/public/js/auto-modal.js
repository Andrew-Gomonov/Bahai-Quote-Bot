// Автоматически открывает модальное окно, если его ID указан в URL (#modalId)
// Работает для первой загрузки страницы и при изменении хэша.
// Требует Bootstrap 5 (Modal)
(function(){
  let currentModal = null;

  function isModalEl(el){
    return el && el.classList && el.classList.contains('modal');
  }

  function openModal(el){
    if(!isModalEl(el)) return;
    // Закрываем ранее открытое модальное окно, если оно ещё открыто
    if(currentModal){
      try{ currentModal.hide(); }catch(e){}
      currentModal = null;
    }
    currentModal = bootstrap.Modal.getOrCreateInstance(el);
    currentModal.show();
  }

  // Пытается найти элемент модали и открыть его. Если элемент ещё не в DOM — ждём появления.
  function tryOpenModalByHash(hash){
    if(!hash || hash.length < 2) return;
    let selector;
    try{
      selector = decodeURIComponent(hash);
    }catch(e){ selector = hash; }

    const el = document.querySelector(selector);
    if(isModalEl(el)){
      openModal(el);
      return;
    }

    // Элемент ещё не загружен: ставим наблюдатель на добавление в DOM (макс 5 сек)
    const timeout = 5000; // мс
    const start = Date.now();
    const observer = new MutationObserver(()=>{
      const found = document.querySelector(selector);
      if(isModalEl(found)){
        openModal(found);
        observer.disconnect();
      }else if(Date.now() - start > timeout){
        observer.disconnect();
      }
    });
    observer.observe(document.body, {childList:true, subtree:true});
  }

  window.addEventListener('hashchange', ()=>tryOpenModalByHash(window.location.hash));
  document.addEventListener('DOMContentLoaded', ()=>tryOpenModalByHash(window.location.hash));
})(); 