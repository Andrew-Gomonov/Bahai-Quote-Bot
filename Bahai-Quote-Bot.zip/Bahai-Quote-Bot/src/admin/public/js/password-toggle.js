// src/admin/public/js/password-toggle.js
document.addEventListener('DOMContentLoaded', function () {
  const togglePasswordButtons = document.querySelectorAll('.password-toggle-btn');
  
  togglePasswordButtons.forEach(button => {
    button.addEventListener('click', function () {
      const passwordInput = this.closest('.input-group').querySelector('input');
      const icon = this.querySelector('i');
      
      if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('bi-eye-slash-fill');
        icon.classList.add('bi-eye-fill');
      } else {
        passwordInput.type = 'password';
        icon.classList.remove('bi-eye-fill');
        icon.classList.add('bi-eye-slash-fill');
      }
    });
  });
}); 