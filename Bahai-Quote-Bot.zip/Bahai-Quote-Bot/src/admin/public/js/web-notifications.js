/**
 * Модуль веб уведомлений
 * Система красивых Toast уведомлений для административной панели
 */

class WebNotifications {
  constructor() {
    this.container = null;
    this.init();
  }

  init() {
    // Создаем контейнер для уведомлений если его нет
    this.container = document.getElementById('notification-container');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'notification-container';
      this.container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
      document.body.appendChild(this.container);
    }
  }

  /**
   * Показать уведомление
   * @param {string} type - Тип уведомления (success, error, warning, info, loading)
   * @param {string} title - Заголовок уведомления
   * @param {string} message - Текст уведомления
   * @param {number} duration - Длительность показа в миллисекундах (0 = не скрывать автоматически)
   * @param {boolean} isHtml - Флаг, указывающий, содержит ли сообщение HTML
   * @returns {string} ID уведомления
   */
  show(type, title, message, duration = 5000, isHtml = false) {
    const notificationId = 'notif-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5);
    
    const notification = document.createElement('div');
    notification.className = 'web-notification';
    notification.id = notificationId;
    
    const alertClass = this.getAlertClass(type);
    const icon = this.getIcon(type);

    // Определяем, нужно ли экранировать контент
    const containsHtml = /<[^>]+>/.test(message);
    const safeMessage = (isHtml || containsHtml) ? message : this.escapeHtml(message);
    
    const wrapperClass = (isHtml || containsHtml) ? '' : 'small';
    
    notification.innerHTML = `
      <div class="alert ${alertClass} alert-dismissible">
        <div class="d-flex align-items-start">
          <i class="bi ${icon} me-2 mt-1 fs-5"></i>
          <div class="flex-grow-1">
            <div class="fw-bold">${this.escapeHtml(title)}</div>
            <div class="${wrapperClass}">${safeMessage}</div>
            ${type === 'loading' ? '<div class="progress mt-2" style="height: 4px;"><div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div></div>' : ''}
          </div>
          <button type="button" class="btn-close" onclick="webNotifications.hide('${notificationId}')"></button>
        </div>
      </div>
    `;
    
    this.container.appendChild(notification);
    
    if (duration > 0) {
      setTimeout(() => this.hide(notificationId), duration);
    }
    
    return notificationId;
  }

  /**
   * Скрыть уведомление
   * @param {string} notificationId - ID уведомления
   */
  hide(notificationId) {
    const notification = document.getElementById(notificationId);
    if (notification) {
      notification.classList.add('hiding');
      setTimeout(() => notification.remove(), 300);
    }
  }

  /**
   * Скрыть все уведомления
   */
  hideAll() {
    const notifications = this.container.querySelectorAll('.web-notification');
    notifications.forEach(notification => {
      this.hide(notification.id);
    });
  }

  /**
   * Показать уведомление об успехе
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность
   */
  success(title, message, duration = 5000) {
    return this.show('success', title, message, duration);
  }

  /**
   * Показать уведомление об ошибке
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность
   */
  error(title, message, duration = 7000) {
    return this.show('error', title, message, duration);
  }

  /**
   * Показать предупреждение
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность
   */
  warning(title, message, duration = 6000) {
    return this.show('warning', title, message, duration);
  }

  /**
   * Показать информационное уведомление
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность
   */
  info(title, message, duration = 5000) {
    return this.show('info', title, message, duration);
  }

  /**
   * Показать уведомление о загрузке
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность (0 = не скрывать)
   */
  loading(title, message, duration = 0) {
    return this.show('loading', title, message, duration);
  }

  /**
   * Получить CSS класс для типа уведомления
   * @param {string} type - Тип уведомления
   * @returns {string} CSS класс
   */
  getAlertClass(type) {
    const classes = {
      'success': 'alert-success',
      'error': 'alert-danger', 
      'warning': 'alert-warning',
      'info': 'alert-info',
      'loading': 'alert-primary'
    };
    return classes[type] || 'alert-info';
  }

  /**
   * Получить иконку для типа уведомления
   * @param {string} type - Тип уведомления
   * @returns {string} CSS класс иконки
   */
  getIcon(type) {
    const icons = {
      'success': 'bi-check-circle-fill',
      'error': 'bi-exclamation-triangle-fill',
      'warning': 'bi-exclamation-triangle-fill', 
      'info': 'bi-info-circle-fill',
      'loading': 'bi-hourglass-split'
    };
    return icons[type] || 'bi-info-circle-fill';
  }

  /**
   * Экранирование HTML символов
   * @param {string} text - Текст для экранирования
   * @returns {string} Экранированный текст
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Создаем глобальный экземпляр
const webNotifications = new WebNotifications();

// Обратная совместимость - глобальные функции
window.showNotification = function(type, title, message, duration) {
  return webNotifications.show(type, title, message, duration);
};

window.hideNotification = function(notificationId) {
  return webNotifications.hide(notificationId);
};

// Экспортируем для модульных систем
if (typeof module !== 'undefined' && module.exports) {
  module.exports = WebNotifications;
} 