document.addEventListener('DOMContentLoaded', function () {
  const newPasswordInput = document.getElementById('newPassword') || document.getElementById('password');
  if (!newPasswordInput) return;

  const strengthMeterContainer = document.getElementById('passwordStrengthMeterContainer') || document.querySelector('.password-strength-meter');

  // Bar and text elements (support different IDs)
  let strengthBar = document.getElementById('newPasswordStrengthBar') || document.getElementById('passwordStrengthBar');
  if (!strengthBar && strengthMeterContainer) {
    strengthBar = strengthMeterContainer.querySelector('.password-strength-meter-bar');
  }

  let strengthText = document.getElementById('newPasswordStrengthText') || document.getElementById('passwordStrengthText');
  if (!strengthText && strengthMeterContainer) {
    strengthText = strengthMeterContainer.querySelector('.password-strength-text');
  }

  const passwordHelpBlock = document.getElementById('passwordHelpBlock');

  if (!strengthBar || !strengthText) return;

  newPasswordInput.addEventListener('input', function () {
    const password = this.value;
    let score = 0;
    let feedback = [];
    const criteria = {
      length: { regex: /.{8,}/, points: 25, message: '8+ символов' },
      lowercase: { regex: /[a-z]/, points: 15, message: 'строчная буква (a-z)' },
      uppercase: { regex: /[A-Z]/, points: 15, message: 'ЗАГЛАВНАЯ буква (A-Z)' },
      number: { regex: /[0-9]/, points: 15, message: 'цифра (0-9)' },
      special: { regex: /[^A-Za-z0-9]/, points: 30, message: 'спец. символ (!@#...)' }
    };

    if (!password) {
      if (strengthMeterContainer) strengthMeterContainer.style.display = 'none';
      if (passwordHelpBlock) passwordHelpBlock.style.display = 'block';
      strengthBar.style.width = '0%';
      strengthText.innerHTML = '';
      strengthBar.className = 'password-strength-meter-bar';
      return;
    }

    if (strengthMeterContainer) strengthMeterContainer.style.display = 'block';
    if (passwordHelpBlock) passwordHelpBlock.style.display = 'none';

    for (const key in criteria) {
      if (criteria[key].regex.test(password)) {
        score += criteria[key].points;
        feedback.push(`<span class="text-success"><i class="bi bi-check-circle-fill"></i> ${criteria[key].message}</span>`);
      } else {
        feedback.push(`<span class="text-danger"><i class="bi bi-x-circle-fill"></i> ${criteria[key].message}</span>`);
      }
    }
    
    score = Math.min(score, 100); // Cap at 100

    let strengthLabel = '';
    let strengthClass = '';

    if (score < 30) {
      strengthLabel = 'Очень слабый';
      strengthClass = 'strength-weak';
    } else if (score < 50) {
      strengthLabel = 'Слабый';
      strengthClass = 'strength-weak';
    } else if (score < 75) {
      strengthLabel = 'Средний';
      strengthClass = 'strength-medium';
    } else if (score < 90) {
      strengthLabel = 'Хороший';
      strengthClass = 'strength-strong';
    } else {
      strengthLabel = 'Отличный';
      strengthClass = 'strength-strong';
    }

    strengthBar.style.width = score + '%';
    strengthBar.className = 'password-strength-meter-bar ' + strengthClass;
    strengthText.innerHTML = `Надежность: <strong>${strengthLabel}</strong><br><small class="d-block mt-1">${feedback.join('<br>')}</small>`;
  });
}); 