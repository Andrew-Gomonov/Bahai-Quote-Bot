document.addEventListener('DOMContentLoaded', function () {
  // Find all file inputs intended for avatar previews
  const avatarInputs = document.querySelectorAll('input[type="file"][name="profile_picture"]');

  avatarInputs.forEach(input => {
    // Find the corresponding preview image and placeholder within the same form or container
    const container = input.closest('.d-flex'); // Adjust selector based on your HTML structure
    if (!container) return;

    const previewImg = container.querySelector('img[id$="AvatarPreview"]');
    const placeholder = container.querySelector('div[id$="AvatarPlaceholder"]');

    if (!previewImg || !placeholder) {
      // Fallback for the original structure in change-credentials
      const simplePreviewContainer = document.getElementById('avatarPreviewContainer');
      const simplePreviewImg = document.getElementById('avatarPreview');
      if (simplePreviewContainer && simplePreviewImg) {
        input.addEventListener('change', function () {
          if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
              simplePreviewImg.src = e.target.result;
              simplePreviewContainer.style.display = 'block';
            };
            reader.readAsDataURL(this.files[0]);
          }
        });
      }
      return;
    }

    input.addEventListener('change', function () {
      if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
          previewImg.src = e.target.result;
          previewImg.classList.remove('d-none');
          if (placeholder) placeholder.classList.add('d-none');
        };
        reader.readAsDataURL(this.files[0]);
      } else {
        previewImg.classList.add('d-none');
        if (placeholder) placeholder.classList.remove('d-none');
      }
    });
  });
}); 