// src/admin/public/js/broadcasts.js
document.addEventListener('DOMContentLoaded', function() {
  // Logic for PUSH modal
  const pushModal = document.getElementById('newPushModal');
  if (pushModal) {
    const chk = pushModal.querySelector('#pushSendNow');
    const dateFld = pushModal.querySelector('input[name="date"]');
    const timeFld = pushModal.querySelector('input[name="time"]');
    
    function togglePushFields() {
      if (!chk || !dateFld || !timeFld) return;
      const disabled = chk.checked;
      dateFld.required = !disabled;
      timeFld.required = !disabled;
      dateFld.disabled = disabled;
      timeFld.disabled = disabled;
      if (disabled) {
        const now = new Date();
        const userTimezoneOffset = now.getTimezoneOffset() * 60000;
        const localNow = new Date(now.getTime() - userTimezoneOffset);
        dateFld.value = localNow.toISOString().slice(0, 10);
        timeFld.value = localNow.toISOString().slice(11, 16);
      }
    }
    chk.addEventListener('change', togglePushFields);
  }

  // Generic logic for GPT message fields in all modals
  function setupGptToggle(modalId, checkboxId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    const gptCheck = modal.querySelector(`#${checkboxId}`);
    const msgField = modal.querySelector('textarea[name="message"]');
    if (!gptCheck || !msgField) return;

    function toggleMessage() {
      msgField.disabled = gptCheck.checked;
      if (gptCheck.checked) {
        msgField.placeholder = `Сообщение будет сгенерировано через ChatGPT`;
        msgField.classList.add('bg-light');
      } else {
        msgField.placeholder = 'Введите текст сообщения для рассылки...';
        msgField.classList.remove('bg-light');
      }
    }
    gptCheck.addEventListener('change', toggleMessage);
    toggleMessage();
  }
  
  setupGptToggle('newPushModal', 'pushUseGpt');
  setupGptToggle('newWeeklyModal', 'weeklyUseGpt');
  setupGptToggle('newDailyModal', 'dailyUseGpt');

  // Generic logic for image preview
  document.querySelectorAll('.image-input').forEach(input => {
    const previewId = input.dataset.preview;
    if (!previewId) return;
    const previewContainer = document.getElementById(previewId);
    if (!previewContainer) return;
    const previewImg = previewContainer.querySelector('.preview-img');
    const openLink = document.getElementById('imgOpen');

    function updatePreview() {
      const url = input.value.trim();
      if (url) {
        previewImg.src = url;
        previewContainer.style.display = 'block';
        if(openLink) {
          openLink.href = url;
          openLink.style.display = url.startsWith('http') ? 'block' : 'none';
        }
      } else {
        previewContainer.style.display = 'none';
        if(openLink) openLink.style.display = 'none';
      }
    }
    input.addEventListener('input', updatePreview);
    updatePreview(); // Initial check
  });

  // Generic logic for clearing image input
  document.querySelectorAll('.image-clear').forEach(button => {
    button.addEventListener('click', () => {
      const input = button.closest('.input-group').querySelector('.image-input');
      if (input) {
        input.value = '';
        // Trigger input event to update preview
        input.dispatchEvent(new Event('input'));
      }
    });
  });
}); 