/**
 * Универсальная система алертов и диалогов подтверждения
 * Современное решение для улучшения UX при удалении элементов в таблицах
 */

class UniversalAlerts {
  constructor() {
    this.modalContainer = null;
    this.init();
  }

  /**
   * Инициализация системы алертов
   */
  init() {
    // Создаем универсальное модальное окно подтверждения
    this.createConfirmModal();
    
    // Привязываем обработчики событий
    this.bindEvents();
    
    console.log('Универсальная система алертов инициализирована (используется webNotifications для toast)');
  }

  /**
   * Создание универсального модального окна подтверждения
   */
  createConfirmModal() {
    if (document.getElementById('universal-confirm-modal')) return;

    const modalHTML = `
      <div class="modal fade universal-confirm-modal" id="universal-confirm-modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <div class="confirm-icon">
                <i class="bi bi-exclamation-triangle-fill"></i>
              </div>
              <h5 class="modal-title">Подтвердите удаление</h5>
            </div>
            <div class="modal-body">
              <div class="confirm-message">
                Вы действительно хотите выполнить это действие?
              </div>
              <div class="confirm-details">
                <div class="detail-item">
                  <i class="bi bi-exclamation-circle text-danger"></i>
                  <span>Это действие необратимо</span>
                </div>
                <div class="detail-item">
                  <i class="bi bi-database text-warning"></i>
                  <span>Данные будут удалены из базы данных</span>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" id="universal-confirm-cancel">
                <i class="bi bi-x-lg me-1"></i>Отмена
              </button>
              <button type="button" class="btn btn-danger" id="universal-confirm-ok">
                <i class="bi bi-trash-fill me-1"></i>Удалить
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
    this.modalContainer = document.getElementById('universal-confirm-modal');
  }

  /**
   * Привязка событий
   */
  bindEvents() {
    // Обработчик кнопки отмены в модальном окне
    const cancelBtn = document.getElementById('universal-confirm-cancel');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        this.hideConfirmModal();
      });
    }

    // Обработчик клика по backdrop
    if (this.modalContainer) {
      this.modalContainer.addEventListener('click', (e) => {
        if (e.target === this.modalContainer) {
          this.hideConfirmModal();
        }
      });
    }

    // Обработчик ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modalContainer.classList.contains('show')) {
        this.hideConfirmModal();
      }
    });
  }

  /**
   * Показать диалог подтверждения удаления
   * @param {Object} options - Опции диалога
   * @param {string} options.title - Заголовок диалога
   * @param {string} options.message - Сообщение
   * @param {string} options.itemName - Название удаляемого элемента
   * @param {string} options.itemId - ID удаляемого элемента
   * @param {Function} options.onConfirm - Callback при подтверждении
   * @param {Function} options.onCancel - Callback при отмене
   * @returns {Promise} Промис с результатом выбора пользователя
   */
  confirmDelete(options = {}) {
    return new Promise((resolve) => {
      const {
        title = 'Подтвердите удаление',
        message = 'Вы действительно хотите удалить этот элемент?',
        itemName = null,
        itemId = null,
        onConfirm = null,
        onCancel = null
      } = options;

      // Обновляем содержимое модального окна
      const modalTitle = this.modalContainer.querySelector('.modal-title');
      const confirmMessage = this.modalContainer.querySelector('.confirm-message');
      const confirmDetails = this.modalContainer.querySelector('.confirm-details');
      const confirmBtn = document.getElementById('universal-confirm-ok');

      modalTitle.textContent = title;
      confirmMessage.textContent = message;

      // Обновляем детали
      let detailsHTML = `
        <div class="detail-item">
          <i class="bi bi-exclamation-circle text-danger"></i>
          <span>Это действие необратимо</span>
        </div>
        <div class="detail-item">
          <i class="bi bi-database text-warning"></i>
          <span>Данные будут удалены из базы данных</span>
        </div>
      `;

      if (itemName) {
        detailsHTML += `
          <div class="detail-item">
            <i class="bi bi-tag text-info"></i>
            <span>Элемент: <strong>${this.escapeHtml(itemName)}</strong></span>
          </div>
        `;
      }

      if (itemId) {
        detailsHTML += `
          <div class="detail-item">
            <i class="bi bi-hash text-muted"></i>
            <span>ID: <strong>${this.escapeHtml(itemId)}</strong></span>
          </div>
        `;
      }

      confirmDetails.innerHTML = detailsHTML;

      // Очищаем предыдущие обработчики
      confirmBtn.onclick = null;

      // Устанавливаем новый обработчик
      confirmBtn.onclick = () => {
        this.hideConfirmModal();
        if (onConfirm) onConfirm();
        resolve(true);
      };

      // Обработчик отмены
      const handleCancel = () => {
        if (onCancel) onCancel();
        resolve(false);
      };

      // Обновляем обработчик отмены
      const cancelBtn = document.getElementById('universal-confirm-cancel');
      cancelBtn.onclick = handleCancel;

      // Показываем модальное окно
      this.showConfirmModal();
    });
  }

  /**
   * Показать модальное окно подтверждения
   */
  showConfirmModal() {
    if (!this.modalContainer) return;

    this.modalContainer.classList.add('show');
    this.modalContainer.style.display = 'block';
    document.body.classList.add('modal-open');

    // Добавляем backdrop
    if (!document.querySelector('.modal-backdrop')) {
      const backdrop = document.createElement('div');
      backdrop.className = 'modal-backdrop fade show';
      document.body.appendChild(backdrop);
    }

    // Фокус на кнопку отмены
    setTimeout(() => {
      const cancelBtn = document.getElementById('universal-confirm-cancel');
      if (cancelBtn) cancelBtn.focus();
    }, 100);
  }

  /**
   * Скрыть модальное окно подтверждения
   */
  hideConfirmModal() {
    if (!this.modalContainer) return;

    this.modalContainer.classList.add('hiding');
    
    setTimeout(() => {
      this.modalContainer.classList.remove('show', 'hiding');
      this.modalContainer.style.display = 'none';
      document.body.classList.remove('modal-open');

      // Удаляем backdrop
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.remove();
      }
    }, 300);
  }

  /**
   * Показать уведомление используя систему веб-уведомлений
   * @param {string} type - Тип уведомления (success, danger, warning, info)
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   * @param {number} duration - Длительность показа в мс (0 = не скрывать)
   * @returns {string} ID уведомления
   */
  showAlert(type, title, message, duration = 5000) {
    // Используем существующую систему веб-уведомлений
    if (typeof webNotifications !== 'undefined') {
      const notificationType = this.mapAlertTypeToNotification(type);
      return webNotifications.show(notificationType, title, message, duration);
    } else {
      console.warn('webNotifications не найден, используем fallback');
      // Fallback для случая когда веб-уведомления не доступны
      alert(`${title}: ${message}`);
      return null;
    }
  }

  /**
   * Мапинг типов алертов к типам уведомлений
   * @param {string} alertType - Тип алерта
   * @returns {string} Тип уведомления для webNotifications
   */
  mapAlertTypeToNotification(alertType) {
    const mapping = {
      'success': 'success',
      'danger': 'error',
      'warning': 'warning',
      'info': 'info'
    };
    return mapping[alertType] || 'info';
  }

  /**
   * Скрыть уведомление
   * @param {string} alertId - ID уведомления
   */
  hideAlert(alertId) {
    if (typeof webNotifications !== 'undefined' && alertId) {
      webNotifications.hide(alertId);
    }
  }

  /**
   * Показать уведомление об успешном удалении
   * @param {string} itemName - Название удаленного элемента
   * @param {string} itemId - ID удаленного элемента
   */
  showDeleteSuccess(itemName = 'Элемент', itemId = null) {
    const message = itemId 
      ? `${itemName} #${itemId} был успешно удален из системы`
      : `${itemName} был успешно удален из системы`;
    
    // Используем webNotifications напрямую для лучшего контроля
    if (typeof webNotifications !== 'undefined') {
      return webNotifications.success('Удаление выполнено', message, 4000);
    } else {
      return this.showAlert('success', 'Удаление выполнено', message, 4000);
    }
  }

  /**
   * Показать уведомление об ошибке удаления
   * @param {string} error - Описание ошибки
   */
  showDeleteError(error = 'Произошла неизвестная ошибка') {
    const message = `Не удалось выполнить удаление: ${error}`;
    
    // Используем webNotifications напрямую для лучшего контроля
    if (typeof webNotifications !== 'undefined') {
      return webNotifications.error('Ошибка удаления', message, 7000);
    } else {
      return this.showAlert('danger', 'Ошибка удаления', message, 7000);
    }
  }

  /**
   * Показать предупреждение
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   */
  showWarning(title, message) {
    if (typeof webNotifications !== 'undefined') {
      return webNotifications.warning(title, message, 6000);
    } else {
      return this.showAlert('warning', title, message, 6000);
    }
  }

  /**
   * Показать информационное уведомление
   * @param {string} title - Заголовок
   * @param {string} message - Сообщение
   */
  showInfo(title, message) {
    if (typeof webNotifications !== 'undefined') {
      return webNotifications.info(title, message, 5000);
    } else {
      return this.showAlert('info', title, message, 5000);
    }
  }

  /**
   * Экранирование HTML символов
   * @param {string} text - Текст для экранирования
   * @returns {string} Экранированный текст
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Универсальная функция для обработки кнопок удаления в таблицах
   * @param {string} selector - CSS селектор кнопок удаления
   * @param {Object} options - Опции обработки
   */
  handleTableDeleteButtons(selector = '.btn-delete', options = {}) {
    const {
      titleAttribute = 'data-title',
      idAttribute = 'data-id',
      nameAttribute = 'data-name',
      urlAttribute = 'data-url',
      formAttribute = 'data-form',
      onSuccess = null,
      onError = null
    } = options;

    document.addEventListener('click', async (e) => {
      const button = e.target.closest(selector);
      if (!button) return;

      e.preventDefault();
      e.stopPropagation();

      const title = button.getAttribute(titleAttribute) || 'Подтвердите удаление';
      const itemId = button.getAttribute(idAttribute);
      const itemName = button.getAttribute(nameAttribute);
      const deleteUrl = button.getAttribute(urlAttribute);
      const formSelector = button.getAttribute(formAttribute);

      // Находим форму для отправки
      let form = null;
      if (formSelector) {
        form = document.querySelector(formSelector);
      } else if (button.form) {
        form = button.form;
      } else {
        form = button.closest('form');
      }

      if (!form && !deleteUrl) {
        this.showDeleteError('Не найден способ выполнения удаления');
        return;
      }

      // Показываем диалог подтверждения
      const confirmed = await this.confirmDelete({
        title: title,
        message: `Вы действительно хотите удалить этот элемент?`,
        itemName: itemName,
        itemId: itemId
      });

      if (!confirmed) return;

      try {
        let response;

        if (deleteUrl) {
          // AJAX удаление
          response = await fetch(deleteUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json',
            }
          });

          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
          }

          const result = await response.json();
          
          if (result.success !== false) {
            this.showDeleteSuccess(itemName || 'Элемент', itemId);
            if (onSuccess) onSuccess(result, button);
          } else {
            throw new Error(result.message || 'Удаление не выполнено');
          }
          
        } else {
          // Обычная отправка формы
          form.submit();
          return;
        }

      } catch (error) {
        console.error('Ошибка удаления:', error);
        this.showDeleteError(error.message);
        if (onError) onError(error, button);
      }
    });
  }

  /**
   * Скрыть все уведомления
   */
  hideAllAlerts() {
    if (typeof webNotifications !== 'undefined') {
      webNotifications.hideAll();
    }
  }

  /**
   * Универсальное подтверждение действия (не только удаления)
   */
  async confirmAction(config) {
    const {
      title = 'Подтверждение действия',
      message = 'Вы действительно хотите выполнить это действие?',
      actionName = 'Действие',
      actionType = 'warning', // warning, danger, info, primary
      confirmText = 'Подтвердить',
      cancelText = 'Отмена',
      showDetails = false,
      details = ''
    } = config;

    return new Promise((resolve) => {
      const modalId = 'universal-action-modal-' + Date.now();
      
      const modalHtml = `
        <div id="${modalId}" class="universal-modal-overlay">
          <div class="universal-modal-container">
            <div class="universal-modal">
              <div class="universal-modal-header">
                <h3 class="universal-modal-title">
                  <i class="bi bi-question-circle"></i>
                  ${title}
                </h3>
              </div>
              <div class="universal-modal-content">
                <div class="confirmation-message">
                  <div class="confirmation-icon ${actionType}">
                    <i class="bi ${this.getIconByType(actionType)}"></i>
                  </div>
                  <div class="confirmation-text">
                    <p>${message}</p>
                    ${showDetails ? `<div class="confirmation-details">${details}</div>` : ''}
                  </div>
                </div>
              </div>
              <div class="universal-modal-actions">
                <button class="universal-btn secondary" data-action="cancel">
                  <i class="bi bi-x-lg"></i>
                  ${cancelText}
                </button>
                <button class="universal-btn ${actionType}" data-action="confirm">
                  <i class="bi ${this.getConfirmIcon(actionType)}"></i>
                  ${confirmText}
                </button>
              </div>
            </div>
          </div>
        </div>
      `;

      // Добавляем модальное окно
      document.body.insertAdjacentHTML('beforeend', modalHtml);
      const modal = document.getElementById(modalId);

      // Показываем модальное окно
      setTimeout(() => modal.classList.add('show'), 10);

      // Обработчики событий
      const finish = (res)=>{ this.closeModal(modal); resolve(res); };

      modal.addEventListener('click', (e) => {
        const actionEl = e.target.closest('[data-action]');
        if(actionEl){
          if(actionEl.dataset.action==='cancel') return finish(false);
          if(actionEl.dataset.action==='confirm') return finish(true);
        }
        if(e.target===modal) return finish(false);
      });

      // Обработка Escape
      const escapeHandler = (e) => {
        if (e.key === 'Escape') {
          this.closeModal(modal);
          resolve(false);
          document.removeEventListener('keydown', escapeHandler);
        }
      };
      document.addEventListener('keydown', escapeHandler);
    });
  }

  /**
   * Валидация формы
   */
  validateForm(form, rules = {}) {
    let isValid = true;
    const errors = [];

    // Очищаем предыдущие ошибки
    form.querySelectorAll('.invalid-feedback, .is-invalid').forEach(el => {
      el.classList.remove('is-invalid');
      if (el.classList.contains('invalid-feedback')) {
        el.remove();
      }
    });

    // Проверяем каждое поле
    Object.keys(rules).forEach(fieldName => {
      const field = form.querySelector(`[name="${fieldName}"]`);
      if (!field) return;

      const rule = rules[fieldName];
      const value = field.value.trim();

      if (rule.required && !value) {
        this.addFieldError(field, rule.requiredMessage || 'Это поле обязательно для заполнения');
        errors.push({ field: fieldName, message: rule.requiredMessage || 'Поле обязательно' });
        isValid = false;
      } else if (value && rule.pattern && !rule.pattern.test(value)) {
        this.addFieldError(field, rule.patternMessage || 'Некорректный формат');
        errors.push({ field: fieldName, message: rule.patternMessage || 'Некорректный формат' });
        isValid = false;
      } else if (value && rule.minLength && value.length < rule.minLength) {
        this.addFieldError(field, `Минимальная длина: ${rule.minLength} символов`);
        errors.push({ field: fieldName, message: `Минимальная длина: ${rule.minLength}` });
        isValid = false;
      } else if (value && rule.maxLength && value.length > rule.maxLength) {
        this.addFieldError(field, `Максимальная длина: ${rule.maxLength} символов`);
        errors.push({ field: fieldName, message: `Максимальная длина: ${rule.maxLength}` });
        isValid = false;
      }
    });

    return { isValid, errors };
  }

  /**
   * Добавление ошибки к полю
   */
  addFieldError(field, message) {
    field.classList.add('is-invalid');
    
    const feedback = document.createElement('div');
    feedback.className = 'invalid-feedback';
    feedback.textContent = message;
    
    field.parentNode.appendChild(feedback);
  }

  /**
   * Уведомление об успешном создании
   */
  successCreated(itemName, message = null) {
    const msg = message || `${itemName} успешно создан`;
    return webNotifications.success('Создание выполнено', msg, 4000);
  }

  /**
   * Уведомление об успешном обновлении
   */
  successUpdated(itemName, message = null) {
    const msg = message || `${itemName} успешно обновлен`;
    return webNotifications.success('Обновление выполнено', msg, 4000);
  }

  /**
   * Уведомление об ошибке создания
   */
  errorCreated(itemName, message = null) {
    const msg = message || `Ошибка при создании ${itemName}`;
    return webNotifications.error('Ошибка создания', msg, 7000);
  }

  /**
   * Уведомление об ошибке обновления
   */
  errorUpdated(itemName, message = null) {
    const msg = message || `Ошибка при обновлении ${itemName}`;
    return webNotifications.error('Ошибка обновления', msg, 7000);
  }

  /**
   * Системное уведомление
   */
  systemNotification(title, message, level = 'info', duration = 5000) {
    const types = {
      'success': 'success',
      'error': 'error', 
      'warning': 'warning',
      'info': 'info'
    };
    
    return webNotifications.show(types[level] || 'info', title, message, duration);
  }

  /**
   * Уведомление о процессе (загрузка)
   */
  processNotification(title, message) {
    return webNotifications.loading(title, message);
  }

  /**
   * Скрыть уведомление о процессе
   */
  hideProcessNotification(notificationId) {
    return webNotifications.hide(notificationId);
  }

  /**
   * Получить иконку по типу действия
   */
  getIconByType(type) {
    const icons = {
      'danger': 'bi-exclamation-triangle-fill',
      'warning': 'bi-exclamation-circle-fill',
      'info': 'bi-info-circle-fill',
      'primary': 'bi-question-circle-fill',
      'success': 'bi-check-circle-fill'
    };
    return icons[type] || 'bi-question-circle-fill';
  }

  /**
   * Получить иконку подтверждения по типу
   */
  getConfirmIcon(type) {
    const icons = {
      'danger': 'bi-trash3',
      'warning': 'bi-exclamation-triangle',
      'info': 'bi-info-circle',
      'primary': 'bi-check',
      'success': 'bi-check'
    };
    return icons[type] || 'bi-check';
  }

  /**
   * Автоматическая обработка форм с подтверждением
   */
  async handleFormSubmission(form, config = {}) {
    const {
      confirmTitle = 'Подтверждение отправки',
      confirmMessage = 'Вы действительно хотите отправить форму?',
      successTitle = 'Форма отправлена',
      successMessage = 'Данные успешно сохранены',
      errorTitle = 'Ошибка отправки',
      errorMessage = 'Не удалось отправить форму',
      needConfirmation = false,
      validation = {}
    } = config;

    // Валидация формы
    if (Object.keys(validation).length > 0) {
      const validationResult = this.validateForm(form, validation);
      if (!validationResult.isValid) {
        this.systemNotification('Ошибка валидации', 'Проверьте правильность заполнения полей', 'warning', 6000);
        return false;
      }
    }

    // Подтверждение (если нужно)
    if (needConfirmation) {
      const confirmed = await this.confirmAction({
        title: confirmTitle,
        message: confirmMessage,
        actionType: 'primary',
        confirmText: 'Отправить',
        cancelText: 'Отмена'
      });

      if (!confirmed) return false;
    }

    // Показываем загрузку
    const loadingId = this.processNotification('Отправка данных', 'Пожалуйста, подождите...');

    try {
      // Отправляем форму
      const formData = new FormData(form);
      const response = await fetch(form.action, {
        method: form.method || 'POST',
        body: formData,
        headers: {
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      this.hideProcessNotification(loadingId);

      if (response.ok) {
        this.systemNotification(successTitle, successMessage, 'success', 4000);
        return true;
      } else {
        throw new Error('Ошибка сервера');
      }
    } catch (error) {
      this.hideProcessNotification(loadingId);
      this.systemNotification(errorTitle, errorMessage, 'error', 7000);
      return false;
    }
  }
}

// Создаем глобальный экземпляр
const universalAlerts = new UniversalAlerts();

// Глобальные функции для обратной совместимости
window.universalAlerts = universalAlerts;

window.confirmDelete = function(options) {
  return universalAlerts.confirmDelete(options);
};

window.showDeleteSuccess = function(itemName, itemId) {
  return universalAlerts.showDeleteSuccess(itemName, itemId);
};

window.showDeleteError = function(error) {
  return universalAlerts.showDeleteError(error);
};

// Экспорт для модульных систем
if (typeof module !== 'undefined' && module.exports) {
  module.exports = UniversalAlerts;
} 